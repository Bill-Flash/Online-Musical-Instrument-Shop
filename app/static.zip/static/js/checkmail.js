$(document).ready(function () {
    // $.ajax(
    //     {
    //         type:'POST',
    //         async:false,
    //         dataType:"JSON",
    //         url:'/api/get_language',
    //         success: function(data) {
    //         language = data['lan'];
    //         }
    //     }
    // );
});
var lgajax = {
    'get':function(args) {
        args['method'] = 'get';
        this.ajax(args);
    },
    'post':function(args) {
        args['method'] = 'post';
        this.ajax(args);
    },
    'ajax':function(args) {
        // 设置csrftoken
        this._ajaxSetup();
        $.ajax(args);
    },
    '_ajaxSetup': function() {
        $.ajaxSetup({
            'beforeSend':function(xhr,settings) {
                if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
                    var csrftoken = $('meta[name=csrf-token]').attr('content');
                    xhr.setRequestHeader("X-CSRFToken", csrftoken)
                }
            }
        });
    }
};
$(function () {
    $("#captcha-btn").click(function (event) {
        event.preventDefault();
        var email = $("input[name='email']").val();
        if(!email){
            if (language==='en'){
                window.alert('please enter email');
            }
            else{
                window.alert('请输入邮箱');
            }
            return;
        }
        var lgajax = {
            'get':function(args) {
                args['method'] = 'get';
                this.ajax(args);
            },
            'post':function(args) {
                args['method'] = 'post';
                this.ajax(args);
            },
            'ajax':function(args) {
                // 设置csrftoken
                this._ajaxSetup();
                $.ajax(args);
            },
            '_ajaxSetup': function() {
                $.ajaxSetup({
                    'beforeSend':function(xhr,settings) {
                        if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
                            var csrftoken = $('meta[name=csrf-token]').attr('content');
                            xhr.setRequestHeader("X-CSRFToken", csrftoken)
                        }
                    }
                });
            }
        };
        lgajax.get({                         // 这里ajax的方法是get方法
            'url': '/email_captcha/',         // 该url需要与视图函数中的路由相同
            'data': {
                'email': email
            },
            'success': function (data) {
                if(data['code'] === 200){
                     if (language==='en'){
                    window.alert('email sent successfully, please check');
                }
                    else{
                    window.alert('邮件发送成功！请注意查收！');
                }
                }else{
                    if (language==='en'){
                        window.alert("send fail");
                }
                    else{
                        window.alert('发送失败');
                }
                }
            },
            'fail': function (error) {
                abort(404);
            }
        });
    });
});

$(function () {
    $("#submitRegister").click(function (event) {
        event.preventDefault();
        var emailE = $("input[name='email']");
        var captchaE = $("input[name='captcha']");

        var email = emailE.val();
        var captcha = captchaE.val();

        lgajax.post({
            'url': '/registeremail/',
            'data': {
                'email': email,
                'captcha': captcha
            },
            'success': function (data) {
                if(data['code'] === 200){
                    let checkBox = $("#customCheck");
                    let email = $("#inputEmail");
                    let username = $("#inputUsername");
                    let password = $("#inputPassword");
                    let confirmation = $("#inputConfirmation");
                    let address = $("#inputAddress")
                    let city = $("#inputCity")
                    let state = $("#inputState")
                    let country = $("#inputCountry")
                    let zip = $("#inputZip")
                    if(email.hasClass("is-valid") &&
                        username.hasClass("is-valid") &&
                        password.hasClass("is-valid") &&
                        confirmation.hasClass("is-valid") &&
                        checkBox.prop("checked")){

                        console.dir("check pass")
                        // sent the information to the backend

                        $.post(
                            '/register',
                            {
                                username: username.val(),
                                email: email.val(),
                                password: password.val(),
                                address: address.val(),
                                city: city.val(),
                                state: state.val(),
                                country: country.val(),
                                zip: zip.val()
                            }
                        ).done(function (response) {
                            let server_code = response['returnValue'];
                            if (server_code === 0) {
                                console.dir("send success")
                                emailE.val("");
                                captchaE.val("");
                                if (language==='en'){
                                        window.alert("login successfully");
                                }
                                    else{
                                        window.alert('恭喜！注册成功！');
                                }
                                window.location.href = "/";
                            }else{
                                console.dir("send fail")
                            }
                        }).fail(function () {
                            console.dir("Fail to connect the server")
                        })

                        return true;
                    }else {
                        // not sent the information
                        console.dir("check not pass")
                        return false
                    }
                }else{
                    if (language === 'en'){
                        window.alert("the confirmation code is wrong");
                    }
                    else{
                        window.alert("验证码错误");
                    }
                    // window.alert("the confirmation code is wrong");
                }
            },
            'fail': function (error) {
                abort(404);
            }
        });
    });
});