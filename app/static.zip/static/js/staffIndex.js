$(document).ready(function(){
 $("#stateChange").click(function (){
  let state = document.getElementById("stateText");
 if (state.textContent === "Open"){
state.textContent= "Closed";
 }else {
  state.textContent= "Open";
 }

 });






});

