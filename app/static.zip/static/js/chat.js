$(document).ready(function() {
    // let translate_btn = $('.chat-message__tools_left')
    // console.log(translate_btn)
    // translate_btn.on("click", translate)
    $('#message-box .simplebar-content').on("click", '.chat-message__tools_left', translate)
    $('#message-box .simplebar-content').on("click", '.chat-message__tools', translate)

})

function translate() {
    let translate_btn = $(this)
    if (translate_btn.parent().children().length == 2) {
        console.log(translate_btn)
        let original = translate_btn.prev().find('p').text().replace(/^\s+|\s+$/g,'')
        console.log(original)
        $.post('/api/getTranslate', {
            'original': original
        }).done(function (response) {
            var trans = response['trans']
            var server_code = response['returnValue']
            if (server_code === 0) {//success: They find the answer
                var new_msga = $(`
                    <div class="chat-message__message-item">
                        <p class="chat-message__item-text">
                        </p>
                    </div>`)
                console.log(trans)
                var new_msga_text = new_msga.find('.chat-message__item-text')
                new_msga_text.text(trans)
                console.log(new_msga)
                translate_btn.prev().before(new_msga)
            }
        }).fail(function () {
        })
    }

}