$(document).ready(function() {

    //img switch
    $('#owl-demo').owlCarousel({
        dotData: true,
        nav: true,
        navText: ['<i class="icon-arrow-left-circle"></i>', '<i class="icon-arrow-right-circle"></i>'],
        addClassActive:true,
        autoPlay: 4000,
        loop:true,
        autoplay: true,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        lazyLoad: true,
        items: 1
    });

    //nl2br
    $.each($('.description'),function (i,val){
        console.log( $(this).html( '<p>' + $(this).text().replaceAll("\r", "<br/>").replaceAll("\n", "<br/>") + '</p>'));
    })
    // text = $('.description').text();
    // text = text.replaceAll("\r", "<br/>").replaceAll("\n", "<br/>");
    // $('.description').html('<p>'+text+'</p>')

    $('#mediaModal').on('click', pauseMedia)

    $('#des-details3').on("click", '.items-more__button', translate)

        // items: 1,  /*onepage显示个数*/
		// 	loop: true, /*支持循环播放*/
		// 	nav: true,  /*显示翻页条*/
		// 	autoplay:false, /*自动播放*/
		// 	autoplayTimeout:3000, /*自动播放间隔时间*/
		// 	autoplayHoverPause:true, /*鼠标悬停停止自动播放*/
		// 	slideBy: 'page', /*滑动的item个数,number or string(page)*/
		// 	mouseDrag: true, /*禁止鼠标拖拽*/
		// 	margin: 0,  /*旋转木马的margin-right*/
});
function playMedia() {
    if ($('#media_src').attr('src') == ''){

    pro_id = window.location.href.match(/\d+$/)[0]
    pro_id = pro_id.slice(-13)
        $.post('/api/getVideo', {
            'pro_id': pro_id
            }).done(function (response) {
                    var server_response = response['src']
                    var server_code = response['returnValue']
                    if(server_code == 0 && server_response !== '/static/video/None'){//success: They find the images

                        $('#media_src').attr("src",server_response);
                        document.querySelector('video').load();//video reload in case the failure of reading src
                    }else {
                        $('video').remove();
                        warn  = $("<em>No matching Video! Browser Error!</em>");
                        $('.modal-body').append(warn)
                    }
            }).fail(function () {
                        $('video').remove();
                        warn  = $("<em>No matching Video! Server internet Error!</em>");
                        $('.modal-body').append(warn)
            })
    } else{
        document.querySelector('video').load();//video load, in case failure of src
    }
}

function pauseMedia() {
    document.querySelector('video').pause();//video pause
}

function translate() {
    let translate_btn = $(this)
    console.log(translate_btn)
    let original = translate_btn.parent().text().replace(/^\s+|\s+$/g,'')
    console.log(original)
    $.post('/api/getTranslate', {
        'original': original
    }).done(function (response) {
        var trans = response['trans']
        var server_code = response['returnValue']
        if (server_code === 0) {//success: They find the answer
            var new_msga = $(`<p class="description-review-bottom"></p>`)
            console.log(trans)
            new_msga.text(trans)
            console.log(new_msga)
            translate_btn.parent().after(new_msga)
            translate_btn.attr("disabled", "disabled")
        }
    }).fail(function () {
    })
}
