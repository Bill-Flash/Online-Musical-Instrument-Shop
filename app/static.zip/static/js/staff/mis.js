let max_page;
let page;
let searchInput;
let rank;

$(document).ready(function () {
    ready_page();
    $("#num").change(function () {
        get_max();
        page = 1;
        get_mis(page);
        document.getElementById("page").value = "1";

    });
    $("#type").change(function () {
        get_max();
        page = 1;
        get_mis(page);
        document.getElementById("page").value = "1";
    });
    $("#search-button").click(function () {
        searchInput = document.getElementById("search-input").value;
        if (searchInput === "") {
            searchInput = "null";
        }
        if (/#/.test(searchInput) === true) {
            console.log(true);
            let presentation = document.getElementById("select2-type-container");
            presentation.title = "All Categories";
            presentation.textContent = "All Categories";
            $("#type").val('all');
        }
        console.log(searchInput);
        get_max();
        page = 1;
        get_mis(page);
        document.getElementById("page").value = "1";
    });

    $("#redirect").click(function () {
        console.log("click");
        let inputPage = document.getElementById("page").value;
        if (inputPage.match(/\D/) != null) {
            alert("Please input integer.");
        } else {
            inputPage = parseInt(inputPage);
            if (inputPage <= 0 || inputPage > max_page) {
                alert("Please input reachable page number.");
            } else {
                get_mis(inputPage);
            }
        }
    });
    $("#before").click(function () {
        if (parseInt(page) - 1 <= 0) {
            alert("This page is the first page.");
        } else {
            page = parseInt(page) - 1;
            get_mis(page);
        }
    });
    $("#after").click(function () {
        console.log(page);
        if (parseInt(page) + 1 > max_page) {
            alert("This page is the last page.");
        } else {
            page = parseInt(page) + 1;
            get_mis(page);
        }
    });
    $("#delete").click(function () {
        delete_product();
    });
    $("#price").click(function (){
        let sort = document.getElementById("price-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            sortReset();
            rank = "price-down";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            sortReset();
            rank = "null";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort";
        }else{
            sortReset();
            rank = "price-up";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#name").click(function (){
        let sort = document.getElementById("name-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            sortReset();
            rank = "name-down";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            sortReset();
            rank = "null";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort";
        }else{
            sortReset();
            rank = "name-up";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#category").click(function (){
        let sort = document.getElementById("category-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            sortReset();
            rank = "category-down";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            sortReset();
            rank = "null";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort";
        }else{
            sortReset();
            rank = "category-up";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#inventory").click(function (){
        let sort = document.getElementById("inventory-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            sortReset();
            rank = "inventory-down";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            sortReset();
            rank = "null";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort";
        }else{
            sortReset();
            rank = "inventory-up";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#status").click(function (){
        let sort = document.getElementById("status-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            sortReset();
            rank = "status-down";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            sortReset();
            rank = "null";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort";
        }else{
            sortReset();
            rank = "status-up";
            get_max();
            page = 1;
            get_mis(page);
            document.getElementById("page").value = "1";
            sort.className = "sort sort--up";
        }
    });
});
function sortReset(){
    let priceSort = document.getElementById("price-sort");
    let nameSort = document.getElementById("name-sort");
    let categorySort = document.getElementById("category-sort");
    let inventorySort = document.getElementById("inventory-sort");
    let statusSort = document.getElementById("status-sort");
    priceSort.className = "sort";
    nameSort.className = "sort";
    categorySort.className = "sort";
    inventorySort.className = "sort";
    statusSort.className = "sort";
}
function ready_page() {
    rank = "null";
    searchInput = "null";
    page = 1;
    ready_types();
    get_max();
    get_mis(page);
}

function ready_types() {
    let type = document.getElementById("type");
    $.post('/staff/get_types', "").done(function (data) {
        for (let i = 0; i < data.length; i++) {
            let opt = document.createElement("option");
            opt.value = data[i];
            opt.textContent = data[i];
            type.appendChild(opt);
        }
    });
}

function get_max() {
    let number = document.getElementById("num").value;
    let type = document.getElementById("type").value;
    $.post('/staff/get_max_mis', {num: number, type: type, search: searchInput,rank:rank}).done(function (data) {
        max_page = parseInt(data);
        console.log(max_page);
    });
}

function get_mis(inputPage) {
    let max_num = document.getElementById("num").value;
    let type = document.getElementById("type").value;
    $.post('/staff/get_mis', {max: max_num, page: inputPage, type: type, search: searchInput,rank:rank}).done(function (data) {
        console.log(data.length);
        empty_mis();
        let table = document.getElementById("mis-body");
        let length = data.length;
        for (let i = 0; i < length; i++) {
            let row = produce_row(data[i]);
            row.id = data[i].product_id.slice(1, data[i].product_id.length);
            table.appendChild(row);
        }

        for (let i = 0; i < 2; i++) {
            let row = document.createElement("tr");
            row.className = "table__row";
            table.appendChild(row);
        }

        document.getElementById("page").value = inputPage;
        page = parseInt(inputPage);
        now_page();
    });
}

function empty_mis() {
    let table = document.getElementById("mis-body");
    let nodes = table.childNodes;
    let len = nodes.length;
    console.log(nodes.length);
    for (let i = len - 1; i >= 0; i--) {
        table.removeChild(nodes[i]);
    }
}

function now_page() {
    let nowPage = document.getElementById("now-page");
    nowPage.textContent = "Now Page: " + page + "/" + max_page;
}

function produce_row(mi) {
    let row = document.createElement("tr");
    row.className = "table__row";
    let id = document.createElement("td");
    id.className = "d-none d-lg-table-cell table__td";
    id.textContent = mi.product_id;
    let name = document.createElement("td");
    name.className = "table__td";
    name.textContent = mi.product_name;
    let type = document.createElement("td");
    type.className = "table__td";
    type.textContent = mi.product_classification;
    let price = document.createElement("td");
    price.className = "table__td";
    price.textContent = "$" + mi.product_price;
    let inventory = document.createElement("td");
    inventory.className = "table__td";
    inventory.textContent = mi.product_inventory;
    let state = document.createElement("td");
    state.className = "d-sm-table-cell table__td";
    state.textContent = mi.product_state;
    let more = createMore(mi.product_id);

    row.appendChild(id);
    row.appendChild(name);
    row.appendChild(type);
    row.appendChild(price);
    row.appendChild(inventory);
    row.appendChild(state);
    row.appendChild(more);

    return row;

}

function createMore(id) {
    let more = document.createElement("td");
    more.className = "table__td table__actions";
    pureId = id.slice(1, id.length);
    more.innerHTML = "<div class=\"items-more\">\n" +
        "                                        <button class=\"items-more__button\">\n" +
        "                                            <svg class=\"icon-icon-more\">\n" +
        "                                                <use xlink:href=\"#icon-more\"></use>\n" +
        "                                            </svg>\n" +
        "                                        </button>\n" +
        "                                        <div class=\"dropdown-items dropdown-items--right\">\n" +
        "                                            <div class=\"dropdown-items__container\">\n" +
        "                                                <ul class=\"dropdown-items__list\">\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/infomi/" + pureId + "\">\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-view\">\n" +
        "                                      <use xlink:href=\"#icon-view\"></use>\n" +
        "                                    </svg></span>Details</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/modmi/" + pureId + "\">\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-plus\">\n" +
        "                                      <use xlink:href=\"#icon-plus\"></use>\n" +
        "                                    </svg></span>Edit</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\"  id=\"" + pureId + "\" onclick='delete_product(this.id)'>\n" +
        "                                                        <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-trash\">\n" +
        "                                      <use xlink:href=\"#icon-trash\"></use>\n" +
        "                                    </svg></span>Delete</a>\n" +
        "                                                    </li>\n" +
        "                                                </ul>\n" +
        "                                            </div>\n" +
        "                                        </div>\n" +
        "                                    </div>";


    return more;

}


function delete_product(id) {
    console.log(id, $("#" + id),);
    $.post('/staff/del_mi', {'id': "#" + id}).done(function (request) {
        let server = request['returnValue'];

        console.log(server);
        if (server === 200) {
            $("#" + id).remove();
            alert('successfully deleted')
        } else {
            console.log(server);
        }
    });
}


