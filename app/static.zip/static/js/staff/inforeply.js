$(document).ready(function(){
    $("#edit").click(function (){
        console.log("click edit");
        let id = document.getElementById("id").textContent;
        console.log(name);
        let route = '../modreply/'+ id;
        console.log(route);
        window.location.href = route;

    });

});