$(document).ready(function(){
    $("#edit").click(function (){
        console.log("click edit");
        let id = document.getElementById("pro_id").textContent;
        console.log(name);
        pureId = id.slice(1,id.length);
        let route = '../modmi/'+ pureId;
        console.log(route);
        window.location.href = route;

    });

});