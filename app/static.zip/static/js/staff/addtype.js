$(document).ready(function(){
    $("#submit").click(function (){
         alert("Successfully add " + document.getElementById("caname").value);
    });


});
