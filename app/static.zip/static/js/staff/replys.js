let max_page;
let page;
let searchInput;

$(document).ready(function () {
    ready_page();
    $("#search-button").click(function (){
        searchInput = document.getElementById("search-input").value;
        if (searchInput == ""){
            searchInput = "null";
        }
        console.log(searchInput+"search");
        get_max();
        page = 1;
        get_replys(page);
        document.getElementById("page").value = "1";
    });
    $("#redirect").click(function () {
        console.log("click");
        let inputPage = document.getElementById("page").value;
        if (inputPage.match(/\D/) != null) {
            alert("Please input integer.");
        } else {
            inputPage = parseInt(inputPage);
            if (inputPage <= 0 || inputPage > max_page) {
                alert("Please input reachable page number.");
            } else {
                get_replys(inputPage);
            }
        }
    });
    $("#before").click(function () {
        if (parseInt(page) - 1 <= 0) {
            alert("This page is the first page.");
        } else {
            page = parseInt(page) - 1;
            get_replys(page);
        }
    });
    $("#after").click(function () {
        console.log(page);
        if (parseInt(page) + 1 > max_page) {
            alert("This page is the last page.");
        } else {
            page = parseInt(page) + 1;
            get_replys(page);
        }
    });
});

function ready_page() {
    searchInput = "null";
    page = 1;
    get_max();
    get_replys(page);
}
function get_max() {
    let number = document.getElementById("num").value;
    // let type = document.getElementById("type").value;
    $.post('/staff/get_max_replys', {num: number, search: searchInput}).done(function (data) {
        max_page = parseInt(data);
        console.log(max_page);
    });
}

function get_replys(inputPage) {
    let max_num = document.getElementById("num").value;
    // let type = document.getElementById("type").value;
    $.post('/staff/get_replys', {max: max_num, page: inputPage, search: searchInput}).done(function (data) {
        console.log(data.length);
        empty_replys();
        let table = document.getElementById("replys-body");
        let length = data.length;
        for (let i = 0; i < length; i++) {
            let row = produce_row(data[i]);
            row.id = data[i].answer_id;
            table.appendChild(row);
        }

        for (let i = 0; i < 2; i++) {
            let row = document.createElement("tr");
            row.className = "table__row";
            table.appendChild(row);
        }

        document.getElementById("page").value = inputPage;
        page = parseInt(inputPage);
        now_page();
    });
}

function empty_replys() {
    let table = document.getElementById("replys-body");
    let nodes = table.childNodes;
    let len = nodes.length;
    console.log(nodes.length);
    for (let i = len - 1; i >= 0; i--) {
        table.removeChild(nodes[i]);
    }
}

function now_page() {
    let nowPage = document.getElementById("now-page");
    nowPage.textContent = "Now Page: " + page + "/" + max_page;
}

function produce_row(reply) {
    let row = document.createElement("tr");
    row.className = "table__row";
    let id = document.createElement("td");
    id.className = "d-none d-lg-table-cell table__td";
    id.textContent = reply.answer_id;
    let question = document.createElement("td");
    question.className = "table__td";
    question.textContent = reply.question;
    let answer = document.createElement("td");
    answer.className = "table__td";
    answer.textContent = reply.answer;

    let more = createMore(reply.answer_id);
    row.appendChild(id);
    row.appendChild(question);
    row.appendChild(answer);
    row.appendChild(more);

    console.log(question)
    return row;

}

function createMore(id) {
    let more = document.createElement("td");
    more.className = "table__td table__actions";
    // pureId = id.slice(1,id.length);
    more.innerHTML = "<div class=\"items-more\">\n" +
        "                                        <button class=\"items-more__button\">\n" +
        "                                            <svg class=\"icon-icon-more\">\n" +
        "                                                <use xlink:href=\"#icon-more\"></use>\n" +
        "                                            </svg>\n" +
        "                                        </button>\n" +
        "                                        <div class=\"dropdown-items dropdown-items--right\">\n" +
        "                                            <div class=\"dropdown-items__container\">\n" +
        "                                                <ul class=\"dropdown-items__list\">\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/inforeply/" + id + "\" >\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-view\">\n" +
        "                                      <use xlink:href=\"#icon-view\"></use>\n" +
        "                                    </svg></span>Details</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/modreply/" + id + "\" >\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-plus\">\n" +
        "                                      <use xlink:href=\"#icon-plus\"></use>\n" +
        "                                    </svg></span>Edit</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\"  id=\"" + id + "\" onclick='delete_reply(this.id)'>\n" +
        "                                                        <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-trash\">\n" +
        "                                      <use xlink:href=\"#icon-trash\"></use>\n" +
        "                                    </svg></span>Delete</a>\n" +
        "                                                    </li>\n" +
        "                                                </ul>\n" +
        "                                            </div>\n" +
        "                                        </div>\n" +
        "                                    </div>";


    return more;

}


function delete_reply(id) {
    $.post('/staff/del_reply', {'id': id}).done(function (request) {
        let server = request['returnValue'];
        if (server === 200) {
            $("#" + id).remove();
        } else {
            console.log(server);
        }
    });
}


