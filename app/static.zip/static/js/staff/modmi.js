$(document).ready(function () {
    // get previous images
    pure_id = document.getElementById('pure_id').textContent;
    let imgs_path = [];
    let status = [];
    $('.imgs_info').hide();
    let index = 0;
    $('.imgs_info').each(function () {
        let str = '/static/img/product/pic/' + $(this).text();
        imgs_path.push(str);
        status.push({caption: 'Present in database', extra: {id: str}});
        index++;
    });
    // js for add images
    let form_id = $('.add-product__form').attr('action');
    let product_id = String(form_id).match(/20.*/)[0];
    $("#input-id").fileinput({
        uploadAsync: true,
        encrypt: 'multipart/form-data',
        uploadUrl: "/staff/uploadImages",
        enableResumableUpload: true,
        resumableUploadOptions: {
            // uncomment below if you wish to test the file for previous partial uploaded chunks
            // to the server and resume uploads from that point afterwards
            // testUrl: "http://localhost/test-upload.php"
        },
        uploadExtraData: {
            'productID': product_id // for access control / security
        },
        // maxFileCount: 5,
        allowedFileTypes: ['image'],    // allow only images
        showCancel: true,
        deleteUrl: "/staff/deleteImages",
        overwriteInitial: false,
        initialPreviewAsData: true,
        initialPreviewShowDelete: true,
        initialPreview: imgs_path,  // if you have previously uploaded preview files
        initialPreviewConfig: status,    // if you have previously uploaded preview files
        theme: 'fas',
    });

    // events in different stages
    $("#input-id").on('fileuploaded', function (event, previewId, index, fileId) {
        console.log('File Uploaded', 'ID: ' + fileId + ', Thumb ID: ' + previewId);
    }).on('fileuploaderror', function (event, data, msg) {
        console.log('File Upload Error', 'ID: ' + data.fileId + ', Thumb ID: ' + data.previewId);
    }).on('filebatchuploadcomplete', function (event, preview, config, tags, extraData) {
        console.log('File Batch Uploaded', preview, config, tags, extraData);
        alert('successfully modified')
        window.location.href = ''
    }).on('');


    // update the changes
    $("#submitImagesForm").on('click', function (e) {
        e.preventDefault(e)
        let post_data = new window.FormData();
        let poster = $("#reposter").prop('files')[0];
        let video = document.getElementById("video").files[0];
        let proname = $("#proname").val()
        let proname2 = $("#proname2").val()
        let description = $("#description").val()
        let description2 = $("#description2").val()
        let state = $("#state").val()
        let type1 = $("#type1").val()
        let type2 = $("#type2").val()
        let price = $("#price").val()
        let inventory = $("#inventory").val()
        if (inventory === '') {
            $("#inventory").focus()
        } else if (inventory.search(/0/i) == 0 && inventory.length > 1) {
            console.log(inventory.search(/0/i));
            console.log(inventory.length);
            $("#inventory").focus();
        }
        if (price === '') {
            $("#price").focus()
        }
        if (proname2 === '') {
            $("#proname2").focus()
        }
        if (proname === '') {
            $("#proname").focus()
        }
        post_data.append('poster', poster);
        post_data.append('video', video);
        post_data.append('state', state);
        post_data.append('description', description);
        post_data.append('description2', description2);
        post_data.append('proname', proname);
        post_data.append('proname2', proname2);
        post_data.append('type1', type1);
        post_data.append('type2', type2);
        post_data.append('price', price);
        post_data.append('inventory', inventory);
        console.log(post_data.get('poster'))
        $.ajax({
            async: false,
            url: '',
            method: 'POST',
            dataType: 'json',//后台返回json格式的返回值
            processData: false,
            contentType: false,
            cache: false,
            data: post_data,
            success: function (response) {
                //如果想把后台返回回来的json对象转字符
                //用JSON.stringify(response)转字符
                if (response.id === 'success') {
                    $("#input-id").fileinput('upload');
                }
            }
        });
    });

    empty_types();
    ready_types();
    get_pictures();
    $("#type1").change(function () {
        console.log("change");
        empty_types();
        change_types();
    });
    $("#poster").click(function () {
        $("#reposter").click();
    });
    $("#reset_pic").on('click', function () {
        $("#reposter").replaceWith($("#reposter").val('').clone(true));
        console.log('reset')
        $("#poster").attr("src", "/static/img/product/pic/upload.png");
    })
    $("#reset_video").on('click', function () {
        $("#video").replaceWith($("#video").val('').clone(true));
        console.log('reset')
        $("#show_video").attr("src", '');
        $("#reset_video").attr("style", 'margin-left: 80px')
    })
    for (i = 1; i <= 10; i++) {
        let b = "#img" + i;
        let a = "#image" + i;
        $(b).change(function () {
            var objUrl = getObjectURL(this.files[0]);
            console.log("objUrl = " + objUrl);
            if (objUrl) {
                $(a).attr("src", objUrl);
            }
        });
    }
    $("#change_video").click(function () {
        $("#video").click();
    });
    $("#image1").click(function () {
        console.log("image1ww");
    });
    $("#reposter").change(function () {
        var objUrl = getObjectURL(this.files[0]);
        console.log("objUrl = " + objUrl);
        if (objUrl) {
            $("#poster").attr("src", objUrl);
        }
    });
    $("#video").change(function () {
        var objUrl = getObjectURL(this.files[0]);
        console.log("objUrl = " + objUrl);
        if (objUrl) {
            $("#show_video").attr("src", objUrl);
            $("#reset_video").attr("style", "float: right")
        }
    });
//     for (i=1; i<=10; i++) {
//     let a ="#image"+i;
//     let b ="#img"+i;
//     $(document).on('click', a , function () {
//         $(b).click();
//     })
// }
    // for (i=1; i<=10; i++) {
    //     let a = "#" + i
    //     let b = "#add" + i
    //     $(document).on('click', a, function () {
    //         $(b).click();
    //     })
    //     $(document).on('change', b, function () {
    //         var objUrl = getObjectURL(this.files[0]);
    //         console.log("objUrl = " + objUrl);
    //         if (objUrl) {
    //             $(a).attr("src", objUrl);
    //         }
    //     })
    // }
    // console.log(p)
});

function ready_types() {
    let id = document.getElementById("id").textContent;
    let region = document.getElementById('type1');
    let types = document.getElementById("type2");
    $.post('/staff/get_type', id).done(function (data) {
        console.log(data[0]);
        console.log(data[1]);

        for (let e in region.childNodes) {
            if (e.value == data[0]) {
                e.selected = true;
            }
        }
        $.post('/staff/get_types', data[0]).done(function (kinds) {
            for (let i = 0; i < kinds.length; i++) {
                let opt = document.createElement("option");
                opt.value = kinds[i];
                opt.textContent = kinds[i];
                if (kinds[i] == data[1]) {
                    opt.selected = true;
                }
                types.appendChild(opt);
            }
        });
        console.log("done");
    });
}

function change_types() {
    let region = document.getElementById('type1');
    let types = document.getElementById("type2");
    console.log(region.value);
    $.post('/staff/get_types', region.value).done(function (data) {
        for (let i = 0; i < data.length; i++) {
            let opt = document.createElement("option");
            opt.value = data[i];
            opt.textContent = data[i];
            types.appendChild(opt);
        }
        console.log("done");
    });
}

function empty_types() {
    let type2 = document.getElementById("type2");
    let nodes = type2.childNodes;
    let len = nodes.length;
    console.log(nodes.length);
    for (let i = len - 1; i >= 0; i--) {
        type2.removeChild(nodes[i]);
    }
}

function get_pictures() {
    let id = document.getElementById("id").textContent;
    let pure_id = id.split(1, id.length);
    $.post('/staff/get_pics', {id: pure_id}).done(function (data) {
        console.log(data);
        for (let i = 0; i < data.length; i++) {
            picture(data[i].img_path, i + 1);
        }
    });

}

function getObjectURL(file) {
    var url = null;
    if (window.createObjectURL !== undefined) {
        url = window.createObjectURL(file);
    } else if (window.URL !== undefined) { // mozilla(firefox)
        url = window.URL.createObjectURL(file);
    } else if (window.webkitURL !== undefined) { // webkit or chrome
        url = window.webkitURL.createObjectURL(file);
    }
    return url;
}

// function picture(path, i) {
//     let pic = document.getElementById("put-img");
//     let new_pic = document.createElement("img");
//     new_pic.src ="../../static/img/product/pic/" + path;
//     new_pic.id = "image" + i;
//     new_pic.height = 150;
//     pic.appendChild(new_pic);
//     new_pic.onclick;
//     p=p+1
//     console.log(new_pic.src);
//     console.log(new_pic.id);
// }

// function addpic(p){
//     let pic = document.getElementById("put-img");
//     let new_pic = document.createElement("img");
//     new_pic.src ="../../static/img/product/pic/upload.png"
//     new_pic.height = 150;
//     pic.appendChild(new_pic);
//     new_pic.id = p
//     let add = document.getElementById("add_pic");
//     let add_pic = document.createElement("input");
//     add_pic.type="file"
//     add_pic.id = "add" + p
//     add.appendChild(add_pic)
// }

