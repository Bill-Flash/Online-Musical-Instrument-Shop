$(document).ready(function () {
    ready_page();
    $("#change-state").click(function () {
        let state = document.getElementById("state");
        $.post('/staff/change_state', state.textContent).done(function (data) {
            state.textContent = data;
        });
    });


});

function ready_page() {
    $.post('/staff/get_new_profit').done(function (data){
        document.getElementById("profit-count").textContent = data[0];
        document.getElementById("profit-count-percentage").textContent = data[1]+"%";
        document.getElementById("profit-count-circle").setAttribute("data-value",data[2]);
    });
    $.post('/staff/get_new_orders').done(function (data){
        document.getElementById("orders-count").textContent = data[0];
        document.getElementById("orders-count-percentage").textContent = data[1]+"%";
        document.getElementById("orders-count-circle").setAttribute("data-value",data[2]);
    });
    $.post('/staff/get_state').done(function (data) {
        let state = document.getElementById("state");
        state.textContent = data;
    });
    let profitChart = document.getElementById("overviewLineChart");
    $.post('/staff/get_weekly_profits').done(function (data) {
        console.log(data.toString());
        let series = "[";
        for (let i = 0; i < data.length - 1; i++) {
            series = series + data[i] + ", ";
        }
        series = series + data[data.length - 1] + "]";
        console.log(series);
        profitChart.setAttribute("data-series", series);
    });
    $.post('/staff/get_index_orders').done(function (data) {
        let per1 = parseInt(data[3]);
        let per2 = parseInt(data[4]);
        let per3 = parseInt(data[5]);
        let total = per1+per2+per3;
        if (total<100){
            per3 = per3+100-total;
        }
        document.getElementById("taskPieChart").setAttribute("data-series",
            "[" + data[3] + ", " + data[4] + ", " + per3 + "]");
        let ce = document.getElementById("ce");
        ce.textContent = data[0];
        document.getElementById("ce-bar").style = "width: "+data[3]+"%; background-color: #FF3D57;";
        let ip =document.getElementById("ip");
        ip.textContent = data[1];
        document.getElementById("ip-bar").style = "width: "+data[4]+"%; background-color: #FDBF5E;";
        let finished = document.getElementById("finished");
        finished.textContent = data[2];
        document.getElementById("finished-bar").style = "width: "+per3+"%; background-color: #22CCE2;";
    });

}

// function getOrders() {
//     $.post('/staff/order_tasks').done(function (data) {
//         document.getElementById("taskPieChart").setAttribute("data-series",
//             "[" + data[0] + ", " + data[1] + ", " + data[2] + "]");
//         console.log(document.getElementById("taskPieChart").getAttributeNode("data-series").value);
//         document.getElementById("finished").textContent = data[0];
//         document.getElementById("in progress").textContent = data[1];
//         document.getElementById("canceled").textContent = data[2];
//     });
//
// }