$(document).ready(function(){
    ready_status();
    let state = document.getElementById("status");
    if (state.textContent!='Exception'&&state.textContent!='Canceled'){
        let reason = document.getElementById("reason");
        reason.className = "col-12 form-group form-group--lg reason non-display";
    }

    $("#edit").click(function (){
        console.log("click edit");
        let id = document.getElementById("id").textContent;
        console.log(name);
        let route = '../modorder/'+ id.slice(1,id.length);
        console.log(route);
        window.location.href = route;

    });


});
function ready_status(){
    let status = document.getElementById("status");
    let paid = document.getElementById("paid");
    let delivery = document.getElementById("delivery");
    let finished = document.getElementById("finished");
    let exception = document.getElementById("exception");
    let canceled = document.getElementById("canceled");
    let p1 = document.getElementById("p1");
    let p2 = document.getElementById("p2");
    let icon2 =  document.getElementById("icon2");
    let text1 =document.getElementById("icon1-text");
    let text2 = document.getElementById("icon2-text");
    console.log(status.textContent);
    if (status.textContent === "Paid(delivery)"){
        paid.className = "node doing";
        p1.className ="proce doing";
        exception.style = "display: none";
        canceled.style="display: none";
        // delivery.className = "status-bar back-blue";
        // finished.className = "status-bar back-green";
        // exception.className = "status-bar back-red";
        // canceled.className = "status-bar back-yellow";
    }
    else if (status.textContent === "Paid(picking up)"){
        paid.className = "node doing";
        delivery.style = "display: none";
        p1.className ="proce doing";
        p2.style ="display: none"
        exception.style = "display: none";
        canceled.style="display: none";
        // delivery.className = "status-bar back-blue";
        // finished.className = "status-bar back-green";
        // exception.className = "status-bar back-red";
        // canceled.className = "status-bar back-yellow";
    }
    else if (status.textContent === "Delivery"){
        console.log(status.textContent);
        paid.className = "node ready";
        delivery.className = "node doing";
        p1.className ="proce done";
        p2.className ="proce doing";
        exception.style = "display: none";
        canceled.style="display: none";
        // finished.className = "status-bar back-green";
        // exception.className = "status-bar back-red";
        // canceled.className = "status-bar back-yellow";
    }
    else if (status.textContent === "Finished"){
        paid.className = "node ready";
        delivery.className = "node ready";
        finished.className = "node ready";
        p1.className ="proce done";
        p2.className ="proce done";
        text2.innerText = "Delivery" + "\n" + "&"+"\n"+"Pick up"
        // text2.style ="margin left = 0"
        exception.style = "display: none";
        canceled.style="display: none";
        // exception.className = "status-bar back-red";
        // canceled.className = "status-bar back-yellow";
    }
    else if (status.textContent === "Exception"){
        document.getElementById("process-04").className="order-process order-warn-process";
        paid.style = "display: none";
        delivery.style = "display: none";
        finished.style = "display: none";
        canceled.style = "display: none";
        p1.style = "display: none";
        p2.style = "display: none";
        exception.className = "node ready";
    }
    else if (status.textContent === "Canceled"){
        paid.className = "node ready";
        icon2.className ="node-icon icon-prepare-refund"
        delivery.className = "node ready";
        finished.style = "display: none";
        p1.className = "proce done";
        p2.className = "proce done";
        exception.style = "display: none";
        canceled.className = "node ready";
        text1.innerText = "Submit application"
        text2.innerText = "Approved"

    }


}