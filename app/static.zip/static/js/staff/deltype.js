$(document).ready(function(){
    empty_types();
    ready_types();
    $("#region").change(function (){
        empty_types();
        ready_types();
    });
    $("#submit").click(function (){
         let types = document.getElementById("type");
         let type = types.value;
        $.post('/staff/del_type',type).done(function (message){
            if (message != "Successfully"){
                alert(message);
            }else {
                alert("Successfully delete "+ type);
                empty_types();
        ready_types();
            }


        });
    });


});

function ready_types(){
    let region = document.getElementById('region');
    let types = document.getElementById("type");
        console.log(region.value);
        $.post('/staff/get_types',region.value).done(function (data){
            for (let i=0; i<data.length;i++){
                let opt = document.createElement("option");
                opt.value = data[i];
                opt.textContent = data[i];
                types.appendChild(opt);
            }
            console.log("done");
        });
}

function empty_types(){
    let types = document.getElementById("type");
    let nodes = types.childNodes;
    let len = nodes.length;
    console.log(nodes.length);
    for (let i= len-1; i>=0;i--){
        types.removeChild(nodes[i]);
    }
}
