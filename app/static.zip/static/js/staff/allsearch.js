let maxMiPage;
let miPage;
let maxOrderPage;
let orderPage;
let search;
let miRank;
let orderRank;
$(document).ready(function () {
    ready_page();
    $("#num").change(function () {
        get_mi_max();
        miPage = 1;
        get_mis(miPage);
        document.getElementById("mi-page").value = "1";
    });
    $("#type").change(function () {
        get_mi_max();
        miPage = 1;
        get_mis(miPage);
        document.getElementById("mi-page").value = "1";
    });
    $("#mi-redirect").click(function () {
        console.log("click");
        let inputPage = document.getElementById("mi-page").value;
        if (inputPage.match(/\D/) != null) {
            alert("Please input integer.");
        } else {
            inputPage = parseInt(inputPage);
            if (inputPage <= 0 || inputPage > maxMiPage) {
                alert("Please input reachable page number.");
            } else {
                get_mis(inputPage);
            }
        }
    });
    $("#mi-before").click(function () {
        if (parseInt(miPage) - 1 <= 0) {
            alert("This page is the first page.");
        } else {
            miPage = parseInt(miPage) - 1;
            get_mis(miPage);
        }
    });
    $("#mi-after").click(function () {
        console.log(miPage);
        if (parseInt(miPage) + 1 > maxMiPage) {
            alert("This page is the last page.");
        } else {
            miPage = parseInt(miPage) + 1;
            get_mis(miPage);
        }
    });
    $("#order-redirect").click(function () {
        console.log("click");
        let inputPage = document.getElementById("page").value;
        if (inputPage.match(/\D/) != null) {
            alert("Please input integer.");
        } else {
            inputPage = parseInt(inputPage);
            if (inputPage <= 0 || inputPage > maxOrderPage) {
                alert("Please input reachable page number.");
            } else {
                get_orders(inputPage);
            }
        }
    });
    $("#order-before").click(function () {
        if (parseInt(orderPage) - 1 <= 0) {
            alert("This page is the first page.");
        } else {
            orderPage = parseInt(orderPage) - 1;
            get_orders(orderPage);
        }
    });
    $("#order-after").click(function () {
        console.log(orderPage);
        if (parseInt(orderPage) + 1 > maxOrderPage) {
            alert("This page is the last page.");
        } else {
            orderPage = parseInt(orderPage) + 1;
            get_orders(orderPage);
        }
    });
    $("#price").click(function (){
        let sort = document.getElementById("price-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            miSortReset();
            miRank = "price-down";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            miSortReset();
            miRank = "null";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort";
        }else{
            miSortReset();
            miRank = "price-up";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#name").click(function (){
        let sort = document.getElementById("name-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            miSortReset();
            miRank = "name-down";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            miSortReset();
            miRank = "null";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort";
        }else{
            miSortReset();
            miRank = "name-up";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#category").click(function (){
        let sort = document.getElementById("category-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            miSortReset();
            miRank = "category-down";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            miSortReset();
            miRank = "null";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort";
        }else{
            miSortReset();
            miRank = "category-up";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#inventory").click(function (){
        let sort = document.getElementById("inventory-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            miSortReset();
            miRank = "inventory-down";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            miSortReset();
            miRank = "null";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort";
        }else{
            miSortReset();
            miRank = "inventory-up";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#status").click(function (){
        let sort = document.getElementById("status-sort");
        let className = sort.className;
        if (className == "sort sort--up"){
            miSortReset();
            miRank = "status-down";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--down";
        }else if(className == "sort sort--down"){
            miSortReset();
            miRank = "null";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort";
        }else{
            miSortReset();
            miRank = "status-up";
            get_mi_max();
            miPage = 1;
            get_mis(miPage);
            document.getElementById("mi-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#customer-name").click(function () {
        let sort = document.getElementById("customer-name-sort");
        let className = sort.className;
        if (className == "sort sort--up") {
            orderSortReset();
            orderRank = "customer-name-down";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--down";
        } else if (className == "sort sort--down") {
            orderSortReset();
            orderRank = "null";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort";
        } else {
            orderSortReset();
            orderRank = "customer-name-up";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#time").click(function () {
        let sort = document.getElementById("time-sort");
        let className = sort.className;
        if (className == "sort sort--up") {
            orderSortReset();
            orderRank = "time-down";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--down";
        } else if (className == "sort sort--down") {
            orderSortReset();
            orderRank = "null";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort";
        } else {
            orderSortReset();
            orderRank = "time-up";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#total-cost").click(function () {
        let sort = document.getElementById("total-cost-sort");
        let className = sort.className;
        if (className == "sort sort--up") {
            orderSortReset();
            orderRank = "total-cost-down";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--down";
        } else if (className == "sort sort--down") {
            orderSortReset();
            orderRank = "null";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort";
        } else {
            orderSortReset();
            orderRank = "total-cost-up";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
    $("#order-status").click(function () {
        let sort = document.getElementById("order-status-sort");
        let className = sort.className;
        if (className == "sort sort--up") {
            orderSortReset();
            orderRank = "status-down";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--down";
        } else if (className == "sort sort--down") {
            orderSortReset();
            orderRank = "null";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort";
        } else {
            orderSortReset();
            orderRank = "status-up";
            get_order_max();
            orderPage = 1;
            get_orders(orderPage);
            document.getElementById("order-page").value = "1";
            sort.className = "sort sort--up";
        }
    });
});
function miSortReset(){
    let priceSort = document.getElementById("price-sort");
    let nameSort = document.getElementById("name-sort");
    let categorySort = document.getElementById("category-sort");
    let inventorySort = document.getElementById("inventory-sort");
    let statusSort = document.getElementById("status-sort");
    priceSort.className = "sort";
    nameSort.className = "sort";
    categorySort.className = "sort";
    inventorySort.className = "sort";
    statusSort.className = "sort";
}
function orderSortReset() {
    let customerNameSort = document.getElementById("customer-name-sort");
    let timeSort = document.getElementById("time-sort");
    let totalCostSort = document.getElementById("total-cost-sort");
    let statusSort = document.getElementById("status-sort");
    customerNameSort.className = "sort";
    timeSort.className = "sort";
    totalCostSort.className = "sort";
    statusSort.className = "sort";
}
function ready_page() {
    miRank = "null";
    search = document.getElementById("search-content").textContent;
    miPage = 1;
    orderPage = 1;
    ready_types();
    get_mi_max();
    get_mis(miPage);
    get_order_max();
    get_orders(orderPage);
}

function ready_types() {
    let type = document.getElementById("type");
    $.post('/staff/get_types', "").done(function (data) {
        for (let i = 0; i < data.length; i++) {
            let opt = document.createElement("option");
            opt.value = data[i];
            opt.textContent = data[i];
            type.appendChild(opt);
        }
    });
}

function get_mi_max() {
    let number = document.getElementById("num").value;
    let type = document.getElementById("type").value;
    $.post('/staff/get_max_mis', {num: number, type: type, search: search, rank:miRank}).done(function (data) {
        maxMiPage = parseInt(data);
    });
}

function get_mis(inputPage) {
    let max_num = document.getElementById("num").value;
    let type = document.getElementById("type").value;
    $.post('/staff/get_mis', {max: max_num, page: inputPage, type: type, search: search,rank: miRank}).done(function (data) {
        empty_mis();
        let table = document.getElementById("mis-body");
        let length = data.length;
        for (let i = 0; i < length; i++) {
            let row = produce_mi_row(data[i]);
            row.id = data[i].product_id.slice(1, data[i].product_id.length);
            table.appendChild(row);
        }

        for (let i = 0; i < 2; i++) {
            let row = document.createElement("tr");
            row.className = "table__row";
            table.appendChild(row);
        }

        document.getElementById("mi-page").value = inputPage;
        miPage = parseInt(inputPage);
        now_mi_page();
    });
}

function empty_mis() {
    let table = document.getElementById("mis-body");
    let nodes = table.childNodes;
    let len = nodes.length;
    for (let i = len - 1; i >= 0; i--) {
        table.removeChild(nodes[i]);
    }
}

function now_mi_page() {
    let nowPage = document.getElementById("mi-now-page");
    nowPage.textContent = "Now Page: " + miPage + "/" + maxMiPage;
}

function produce_mi_row(mi) {
    let row = document.createElement("tr");
    row.className = "table__row";
    let id = document.createElement("td");
    id.className = "d-none d-lg-table-cell table__td";
    id.textContent = mi.product_id;
    let name = document.createElement("td");
    name.className = "table__td";
    name.textContent = mi.product_name;
    let type = document.createElement("td");
    type.className = "table__td";
    type.textContent = mi.product_classification;
    let price = document.createElement("td");
    price.className = "table__td";
    price.textContent = "$" + mi.product_price;
    let inventory = document.createElement("td");
    inventory.className = "table__td";
    inventory.textContent = mi.product_inventory;
    let state = document.createElement("td");
    state.className = "d-sm-table-cell table__td";
    state.textContent = mi.product_state;
    let more = createMiMore(mi.product_id);

    row.appendChild(id);
    row.appendChild(name);
    row.appendChild(type);
    row.appendChild(price);
    row.appendChild(inventory);
    row.appendChild(state);
    row.appendChild(more);

    return row;

}

function createMiMore(id) {
    let more = document.createElement("td");
    more.className = "table__td table__actions";
    pureId = id.slice(1, id.length);
    more.innerHTML = "<div class=\"items-more\">\n" +
        "                                        <button class=\"items-more__button\">\n" +
        "                                            <svg class=\"icon-icon-more\">\n" +
        "                                                <use xlink:href=\"#icon-more\"></use>\n" +
        "                                            </svg>\n" +
        "                                        </button>\n" +
        "                                        <div class=\"dropdown-items dropdown-items--right\">\n" +
        "                                            <div class=\"dropdown-items__container\">\n" +
        "                                                <ul class=\"dropdown-items__list\">\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/infomi/" + pureId + "\">\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-view\">\n" +
        "                                      <use xlink:href=\"#icon-view\"></use>\n" +
        "                                    </svg></span>Details</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/modmi/" + pureId + "\">\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-plus\">\n" +
        "                                      <use xlink:href=\"#icon-plus\"></use>\n" +
        "                                    </svg></span>Edit</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\"  id=\"" + pureId + "\" onclick='delete_product(this.id)'>\n" +
        "                                                        <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-trash\">\n" +
        "                                      <use xlink:href=\"#icon-trash\"></use>\n" +
        "                                    </svg></span>Delete</a>\n" +
        "                                                    </li>\n" +
        "                                                </ul>\n" +
        "                                            </div>\n" +
        "                                        </div>\n" +
        "                                    </div>";


    return more;

}


function delete_product(id) {
    console.log(id, $("#" + id),);
    $.post('/staff/del_mi', {'id': "#" + id}).done(function (request) {
        let server = request['returnValue'];

        console.log(server);
        if (server === 200) {
            $("#" + id).remove();
        } else {
            console.log(server);
        }
    });
}

function get_order_max() {
    let number = document.getElementById("num").value;
    // let type = document.getElementById("type").value;
    $.post('/staff/get_max_orders', {num: number, search: search,rank:orderRank}).done(function (data) {
        maxOrderPage = parseInt(data);
        console.log(maxOrderPage);
    });
}

function get_orders(inputPage) {
    let max_num = document.getElementById("num").value;
    // let type = document.getElementById("type").value;
    $.post('/staff/get_orders', {max: max_num, page: inputPage, search: search,rank:orderRank}).done(function (data) {
        console.log(data.length);
        empty_orders();
        let table = document.getElementById("orders-body");
        let length = data.length;
        for (let i = 0; i < length; i++) {
            let row = produce_order_row(data[i]);
            row.id = data[i].order_id;
            table.appendChild(row);
        }

        for (let i = 0; i < 2; i++) {
            let row = document.createElement("tr");
            row.className = "table__row";
            table.appendChild(row);
        }

        document.getElementById("order-page").value = inputPage;
        orderPage = parseInt(inputPage);
        now_order_page();
    });
}

function empty_orders() {
    let table = document.getElementById("orders-body");
    let nodes = table.childNodes;
    let len = nodes.length;
    console.log(nodes.length);
    for (let i = len - 1; i >= 0; i--) {
        table.removeChild(nodes[i]);
    }
}

function now_order_page() {
    let nowPage = document.getElementById("order-now-page");
    nowPage.textContent = "Now Page: " + orderPage + "/" + maxOrderPage;
}

function produce_order_row(order) {
    let row = document.createElement("tr");
    row.className = "table__row";
    let id = document.createElement("td");
    id.className = "d-none d-lg-table-cell table__td";
    id.textContent = order.order_id;
    let userId = document.createElement("td");
    userId.className = "table__td";
    userId.textContent = order.orderUser_username;
    let time = document.createElement("td");
    time.className = "table__td";
    time.textContent = order.create_time;
    let totalCost = document.createElement("td");
    totalCost.className = "table__td";
    totalCost.textContent = "$" + order.total_cost;
    let status = document.createElement("td");
    status.className = "table__td";
    status.textContent = order.order_state;
    let priority = document.createElement("td");
    priority.className = "table__td";
    if (order.order_priority == 'Yes') {
        priority.innerHTML = '&emsp;' + '<svg t="1652964718816" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3851" width="25" height="25"><path d="M275.7 653.7c0.4-8.2-2.2-16.2-7.3-22.6L100.7 421 352 348.6c8.1-2.3 15-7.6 19.4-14.9l137.5-229.4 142.2 226.1c4.5 7.2 11.5 12.4 19.7 14.5l252.7 66.5-163.3 214c-4.9 6.5-7.4 14.5-6.8 22.7l17.6 272-242.2-95.5c-3.9-1.5-8-2.3-12.1-2.3-4.4 0-8.7 0.9-12.8 2.6l-240.1 101 11.9-272.2z" fill="#F8D351" p-id="3852"></path><path d="M509.4 152.1L630 343.8c7.9 12.6 20.2 21.6 34.5 25.4l216.5 57-140.7 184.2c-8.6 11.3-12.8 25.3-11.9 39.5l15.1 232.7-205.5-81c-6.8-2.7-14-4-21.3-4-7.8 0-15.3 1.5-22.5 4.5l-203.7 85.7 10.2-232.9c0.6-14.2-3.9-28.2-12.8-39.2l-144.4-181 215.4-62c14.2-4.1 26.3-13.4 33.9-26.1l116.6-194.5m-0.9-88.1c-2.7 0-5.4 1.4-7.1 4.1L349.9 320.9c-1.1 1.8-2.8 3.2-4.8 3.8l-275 79.2c-5.8 1.7-8 9-4.2 13.8l183 229.3c1.3 1.6 2 3.7 1.9 5.9L237.7 951c-0.2 5.1 3.8 9 8.3 9 1 0 2.1-0.2 3.1-0.6l264.5-111.2c1-0.4 2.1-0.6 3.1-0.6s2 0.2 3 0.6l266.7 105.1c1 0.4 2 0.6 3 0.6 4.6 0 8.6-4 8.3-9.2l-19.3-298c-0.1-2.1 0.5-4.2 1.8-5.9l178.1-233.4c3.7-4.9 1.4-12.1-4.5-13.7l-276.6-72.8c-2-0.5-3.8-1.8-4.9-3.6L515.5 67.9c-1.7-2.6-4.3-3.9-7-3.9z" fill="#3A3644" p-id="3853"></path><path d="M291 876l177.8-95 179.4 32.9c4.8 1.3 9.7 1.9 14.7 1.9 16 0 31.5-6.7 42.4-18.4 9.9-10.6 15.6-24.6 15.8-39.1l7.5-106.5 15 230.9-205.5-81c-6.8-2.7-14-4-21.3-4-7.8 0-15.3 1.5-22.5 4.5l-203.7 85.7 0.4-11.9z m444.4-321.9l85.2-143.8 60.3 15.9-140.6 184.2c-5 6.6-8.6 14.1-10.5 22.1l5.6-78.4z" fill="#D5B440" p-id="3854"></path><path d="M370.9 633.4L240.1 406.8l49.5-14.3 124.6 215.8c4.1 7.1 1.7 16.4-5.5 20.5l-17.3 10c-7.1 4.2-16.4 1.7-20.5-5.4z m191 30.8L384.6 357.1s-7.6 8.1-16.3 11.9c-3.3 2.4-29.2 9.3-29.2 9.3L516.8 686c4.1 7.1 13.3 9.6 20.5 5.5l17.3-10c7.1-4.1 9.6-13.4 7.3-17.3z" fill="#FFE8B0" p-id="3855"></path></svg>'
    }
    if (order.order_state == "Paid(delivery)") {
        status.className = "d-sm-table-cell table__td font-coral";
    } else if (order.order_state == "Paid(picking up)") {
        status.className = "d-sm-table-cell table__td font-coral";
    } else if (order.order_state == "Delivery") {
        status.className = "d-sm-table-cell table__td font-blue";
    } else if (order.order_state == "Finished") {
        status.className = "d-sm-table-cell table__td font-green";
    } else if (order.order_state == "Exception") {
        status.className = "d-sm-table-cell table__td font-red";
    } else if (order.order_state == "Canceled") {
        status.className = "d-sm-table-cell table__td font-yellow";
    }
    console.log(order.product_name);
    let more = createOrderMore(order.order_id);

    row.appendChild(id);
    row.appendChild(userId);
    row.appendChild(time);
    row.appendChild(totalCost);
    row.appendChild(status);
    row.appendChild(priority)
    row.appendChild(more);

    return row;

}

function createOrderMore(id) {
    let more = document.createElement("td");
    more.className = "table__td table__actions";
    pureId = id.slice(1,id.length);
    more.innerHTML = "<div class=\"items-more\">\n" +
        "                                        <button class=\"items-more__button\">\n" +
        "                                            <svg class=\"icon-icon-more\">\n" +
        "                                                <use xlink:href=\"#icon-more\"></use>\n" +
        "                                            </svg>\n" +
        "                                        </button>\n" +
        "                                        <div class=\"dropdown-items dropdown-items--right\">\n" +
        "                                            <div class=\"dropdown-items__container\">\n" +
        "                                                <ul class=\"dropdown-items__list\">\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/infoorder/" + pureId + "\" >\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-view\">\n" +
        "                                      <use xlink:href=\"#icon-view\"></use>\n" +
        "                                    </svg></span>Details</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\" href=\"/staff/modorder/" + pureId + "\" >\n" +
        "                                                            <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-plus\">\n" +
        "                                      <use xlink:href=\"#icon-plus\"></use>\n" +
        "                                    </svg></span>Edit</a>\n" +
        "                                                    </li>\n" +
        "                                                    <li class=\"dropdown-items__item\">\n" +
        "                                                        <a class=\"dropdown-items__link\"  id=\"" + pureId + "\" onclick='delete_order(this.id)'>\n" +
        "                                                        <span class=\"dropdown-items__link-icon\">\n" +
        "                                    <svg class=\"icon-icon-trash\">\n" +
        "                                      <use xlink:href=\"#icon-trash\"></use>\n" +
        "                                    </svg></span>Delete</a>\n" +
        "                                                    </li>\n" +
        "                                                </ul>\n" +
        "                                            </div>\n" +
        "                                        </div>\n" +
        "                                    </div>";


    return more;

}


function delete_order(id) {
    $.post('/staff/del_order', {'id': id}).done(function (request) {
        let server = request['returnValue'];
        if (server === 200) {
            $("#" + id).remove();
        } else {
            console.log(server);
        }
    });

}