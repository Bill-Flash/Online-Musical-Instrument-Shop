$(document).ready(function(){
    let state = document.getElementById("state");
    let reason = document.getElementById("reason");
    console.log(state.value);
    if (state.value!=='Exception'&&state.value!=='Canceled'){
        reason.className = "col-12 form-group form-group--lg reason non-display";
    }
    $("#state").change(function (){
        if (state.value!=='Exception'&&state.value!=='Canceled'){
        reason.className = "col-12 form-group form-group--lg reason non-display";
    }else{
            reason.className = "col-12 form-group form-group--lg reason";
        }
    });


});