$(document).ready(function () {
    get_id();
    // js for add images
    // events in different stages
    $("#input-id").on('fileuploaded', function (event, data, previewId, index, fileId) {
        console.log('File Uploaded', 'ID: ' + fileId + ', Thumb ID: ' + previewId);
    }).on('fileuploaderror', function (event, data, msg) {
        console.log('File Upload Error', 'ID: ' + data.fileId + ', Thumb ID: ' + data.previewId);
    }).on('filebatchuploadcomplete', function (event, preview, config, tags, extraData) {
        console.log('File Batch Uploaded', preview, config, tags, extraData);
         alert('successfully added')
        window.location.href = ''
    })
    $("#reset_video").on('click', function (){
        $("#video").replaceWith($("#video").val('').clone(true));
        console.log('reset')
        $("#show_video").attr("src", '');
        $("#reset_video").attr("style", 'margin-left: 80px')
    })
    $("#reset_pic").on('click', function (){
        $("#poster").replaceWith($("#poster").val('').clone(true));
        console.log('reset')
        $("#show_poster").attr("src", "/static/img/product/pic/upload.png");
    })
    $("#submitImagesForm").on('click', function (e) {
        e.preventDefault(e)
        let post_data = new window.FormData();
        let poster = $("#poster").prop('files')[0];
        let video = document.getElementById("video").files[0];
        let final_id = $("#new_id").val()
        let proname = $("#proname").val()
        let proname2 = $("#proname2").val()
        let description = $("#description").val()
        let description2 = $("#description2").val()
        let state = $("#state").val()
        let type1 = $("#type1").val()
        let type2 = $("#type2").val()
        let price = $("#price").val()
        let inventory = $("#inventory").val()
        if (inventory === ''){
            $("#inventory").focus()
        }else if (inventory.search(/0/i)==0 && inventory.length>1){
            console.log(inventory.search(/0/i));
            console.log(inventory.length);
            $("#inventory").focus();
        }

        if (price === ''){
            $("#price").focus()
        }
        if (proname2 === ''){
            $("#proname2").focus()
        }
        if (proname === ''){
            $("#proname").focus()
        }
        post_data.append('poster', poster);
        post_data.append('video', video);
        post_data.append('state', state);
        post_data.append('description', description);
        post_data.append('description2', description2)
        post_data.append('proname', proname);
        post_data.append('proname2', proname2);
        post_data.append('type1', type1);
        post_data.append('type2', type2);
        post_data.append('price', price);
        post_data.append('inventory', inventory);
        post_data.append('final_id', final_id)
        console.log(post_data.get('final_id'))
        $.ajax({
            async: true,
            url: '/staff/newmi',
            method: 'POST',
            dataType: 'json',//后台返回json格式的返回值
            processData : false,
            contentType: false,
            cache: false,
            data: post_data,
            success: function (response) {
                //如果想把后台返回回来的json对象转字符
                //用JSON.stringify(response)转字符
                if (response.id === 'success') {
                    $("#input-id").fileinput('upload');
                }
            }
        });
    });
    // $("#poster").fileinput();
    // $("#images").fileinput({
    //         'theme': 'explorer-fas',
    //         'uploadUrl': '#',
    //         overwriteInitial: false,
    //         initialPreviewAsData: true,
    // });
    empty_types();
    ready_types();
    $("#type1").change(function () {
        empty_types();
        ready_types();
    });
    $("#show_poster").click(function(){
        $("#poster").click();
    });
    $("#change_video").click(function (){
        $("#video").click();
    });
    $("#poster").change(function () {
        var objUrl = getObjectURL(this.files[0]);
        console.log("objUrl = " + objUrl);
        if (objUrl) {
            $("#show_poster").attr("src", objUrl);
        }
    })
    $("#video").change(function () {
        var objUrl = getObjectURL(this.files[0]);
        console.log("objUrl = " + objUrl);
        if (objUrl) {
            $("#show_video").attr("src", objUrl);
            $("#reset_video").attr("style", "float: right")
        }
    });
});

function ready_types() {
    let region = document.getElementById('type1');
    let types = document.getElementById("type2");
    console.log(region.value);
    $.post('/staff/get_types', region.value).done(function (data) {
        for (let i = 0; i < data.length; i++) {
            let opt = document.createElement("option");
            opt.value = data[i];
            opt.textContent = data[i];
            types.appendChild(opt);
        }
        console.log("done");
    });
}

function empty_types() {
    let type2 = document.getElementById("type2");
    let nodes = type2.childNodes;
    let len = nodes.length;
    console.log(nodes.length);
    for (let i = len - 1; i >= 0; i--) {
        type2.removeChild(nodes[i]);
    }
}

function getObjectURL(file) {
    var url = null;
    if (window.createObjectURL != undefined) {
        url = window.createObjectURL(file);
    } else if (window.URL != undefined) { // mozilla(firefox)
        url = window.URL.createObjectURL(file);
    } else if (window.webkitURL != undefined) { // webkit or chrome
        url = window.webkitURL.createObjectURL(file);
    }
    return url;
}

function get_id() {
    $.post('/staff/get_id').done(function (data) {
        console.log("DSADSADAS", data.id);
        let img_id = data.id;
        $('#new_id').val(img_id)
        console.log(img_id);
        $("#input-id").fileinput({
            uploadUrl: "/staff/newImages",
            uploadAsync: true,
            encrypt: 'multipart/form-data',
            enableResumableUpload: true,
            resumableUploadOptions: {
                // uncomment below if you wish to test the file for previous partial uploaded chunks
                // to the server and resume uploads from that point afterwards
                // testUrl: "http://localhost/test-upload.php"
            },
            uploadExtraData: {
                'id': img_id
            },
            // maxFileCount: 5,
            allowedFileTypes: ['image'],    // allow only images
            showCancel: true,
            deleteUrl: "deleteImages",
            overwriteInitial: false,
            initialPreviewAsData: true,
            initialPreviewShowDelete: true,
            theme: 'fas',
        })

    })
}

