
$(document).ready(function() {
    $("#buy").on('click',make_order)
    $("#confirm_exit").on('click',jumpToInfo)
    let service = $('#service').children('option:selected').val();
    if (service === 'Delivery' || service === '快递'){
        $('.Address').show('slow')
    }else{
        $('.Address').hide('slow')
    }
    //delivery information
    $('#service').change(function (){
        let service = $(this).children('option:selected').val();
        if (service === 'Delivery' || service === '快递'){
            $('.Address').show('slow')
        }else{
            $('.Address').hide('slow')
        }
    });
});


function jumpToInfo(){
    window.location.href = '/shopping_cart'
}

function make_order() {
    console.log('buy')
    let delivery
    let service = $("#service").val()
    let address
    let state
    let phone
    if (service === "Delivery" || service==='快递') {
        delivery = 0
        state = 'Paid(delivery)'
        address = $("#country").text() + $("#city").text()
        phone = $("#phone").text()
        let regx = /^(-)?\d+(\.\d+)?$/;
        if (regx.exec(phone) == null || phone === "") {
            phone = 'unknown'
        }
    }
    else {
        delivery = 1
        state = 'Paid(picking up)'
        address = 'unknown'
        phone = 'unknown'
    }
    $.ajax({
        type: "POST",
        dataType: "json",
        url: '/api/make_order',
        // async:false,
        data: {
        'phone':phone,
        'address':address,
        'delivery':delivery,
        'state':state,
        },
        // traditional: true,
        error: function (XMLHttpRequest, textStatus, errorThrown) {window.alert("server failed")},
        success: function (response){
            let code = response['returnValue'];
            if (language === 'en'){
                if(code===0){
                    modalConfirmation("purchase successfully");
                }
                else if (code===1){
                    modalConfirmation("something you buy are now closed for buying");
                }
                else if (code===2){
                    modalConfirmation("something you buy is out of inventory");
                }
            }else{
                if(code===0){
                    modalConfirmation("购买成功");
                }
                else if (code===1){
                    modalConfirmation("商品已经下架");
                }
                else if (code===2){
                    modalConfirmation("商品已经售罄");
                }
            }

        }
    });
}


function checkService(){
    let service = $(this).children('option:selected').val();
    if (service === 'Delivery' || service === '快递'){
        $('.Address').show('slow')
    }else{
        $('.Address').hide('slow')
    }
}
