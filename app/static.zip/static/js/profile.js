var lgajax = {
    'get':function(args) {
        args['method'] = 'get';
        this.ajax(args);
    },
    'post':function(args) {
        args['method'] = 'post';
        this.ajax(args);
    },
    'ajax':function(args) {
        // 设置csrftoken
        this._ajaxSetup();
        $.ajax(args);
    },
    '_ajaxSetup': function() {
        $.ajaxSetup({
            'beforeSend':function(xhr,settings) {
                if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
                    var csrftoken = $('meta[name=csrf-token]').attr('content');
                    xhr.setRequestHeader("X-CSRFToken", csrftoken)
                }
            }
        });
    }
};
let first = null;
let current = null;
let before = null;
let cancel = null;
$(document).ready(function () {
    bsCustomFileInput.init()
    // change the style of the class "page-content" temporarily
    $(".cus-profile").parent().css("max-width", "100%")
    $(".widget").css("background-color", null)
    // email input

    // verify button
    $("#changeVerification")

    // verification code
    $("#changeCode")

    // old password
    $("changeOldpassword")

    // new password
    $("changeNewpassword")
    $(":input[name='update2']").on("click", changeInformation2)
    $(":input[name='update4']").on("click", changePassword)
    $("#changeHead").on("click", changeInformation)
    // $("#validatedInputGroupCustomFile").on("change",chooseProfilePhoto);
    let cancel_ele = null;
    $('.real_cancel').children().on('mouseover', function (){
        if (language === 'en'){
            $(this).parent().parent().children('.hint').children().text('Cancel Order')
        }
        else{
            $(this).parent().parent().children('.hint').children().text('删除订单')
        }
        // $(this).parent().parent().children('.hint').children().text('Cancel Order')
        $(this).children().attr('src', 'static/bootstrap-icons/icons/x-circle-fill.svg')
    })
    $('.real_cancel').children().on('mouseout', function (){
        $(this).parent().parent().children('.hint').children().text('')
        $(this).children().attr('src', 'static/bootstrap-icons/icons/x-circle.svg')
    })
    $('.real_cancel').children().on('click', function (){
        $('#cancelModal').addClass('is-active')
        $('#cancelModal').addClass('is-animate')
        cancel_ele = $(this).parent().parent()
        cancel = $(this).parent().parent().children().children('.view-all').attr('id')
    })
    $('#submit_reason').on('click', function () {
        if (cancel != null){
            let reason = $(this).parent().parent().children('#cancel-body').children("#cancel-reason").val()
            if (reason.length !== 0){
                $.post('/cancel_order', {orderID: cancel, reason: reason}).done(function (response) {
                    if (response['success'] == 0){
                        if (language === 'en'){
                            toastAddSuccess('Wait for administrator approval')
                            cancel_ele.children('.order-state').text('Exception')
                        }
                        else{
                            toastAddSuccess('等待客服同意')
                            cancel_ele.children('.order-state').text('异常')
                        }
                        // toastAddSuccess('Wait for administrator approval')
                        // cancel_ele.children('.order-state').text('Exception')
                        cancel_ele.children('.order-state').css('background-color', 'rgba(236, 63, 85, 0.8)')
                        cancel_ele.children().children('.mark-received').hide()
                        cancel_ele.children('.real_cancel').children().hide()
                    }
                })
            }else{
                if (language === 'en'){
                    toastAddFail('Cancel fail because empty reason')
                }
                else{
                    toastAddFail('取消失败，没有填写原因')
                }
                    // toastAddFail('Cancel fail because empty reason')
            }
        }
        cancel = null;
    })

    $('.cancel_order').children().on('mouseover', function (){
        if (language === 'en'){
            $(this).parent().parent().children('.hint').children().text('Delete Order')
        }
        else{
            $(this).parent().parent().children('.hint').children().text('删除订单')
        }
        $(this).children().attr('src', 'static/bootstrap-icons/icons/trash-fill.svg')
    })
    $('.cancel_order').children().on('mouseout', function (){
        $(this).parent().parent().children('.hint').children().text('')
        $(this).children().attr('src', 'static/bootstrap-icons/icons/trash.svg')
    })
    $('.cancel_order').children().on('click',function () {
        let state = $(this).parent().parent().children('.order-state').text()
        let id = $(this).parent().parent().children().children('.view-all').attr('id')
        let order_ele =  $(this).parent().parent().parent().parent()
        console.log(String(state))
        if (String(state) == 'Canceled' || String(state) == 'Finished'){
            console.log('delete')
            $.post('/delete_order', {orderID: String(id)}).done(function (response) {
                if( response['success'] == 0 ){
                    if (language === 'en'){
                        toastAddSuccess('Delete Success')
                    }
                    else{
                        toastAddSuccess('删除成功')
                    }
                    // console.log(state.text())
                    // state.text('Canceled');
                    // state.css('background-color', 'rgba(176, 174, 174, 0.87)')
                    // cancel.hide()
                    // btn.hide()
                    order_ele.remove()
                }
            })
        }

    })
    
    $(".view-all").on('click', sendId)
    $(".mark-received").each(function (){
        let state = $(this).parent().parent().children('.order-state')
        let str = String(state.text())
        console.log(state)
        let dele = $(this).parent().parent().children('.cancel_order')
        let cancel = $(this).parent().parent().children('.real_cancel')
        dele.hide()
        cancel.hide()
        if (str == 'Finished' || str == '结束'){
            state.css('background-color', '#0be20c')
            $(this).addClass('comment')
            if(str == 'Finished'){
                $(this).text( "Add a comment" )
            }else{
                $(this).text( "添加评论" )
            }
            dele.show()
        }
        else if (str == 'Exception' || str == '异常'){
            state.css('background-color', 'rgba(236,63,85,0.8)')
            $(this).remove()
        }else if (str == 'Canceled' || str == '取消'){
            state.css('background-color', 'rgba(176,174,174,0.87)')
            $(this).remove()
            dele.show()
        }else{
            if(str != 'Delivery' && str != '运送中'){
                cancel.show()
            }
        }
    })

    // clear the storage if page is reloaded
    sessionStorage.clear()

    // trigger of received / comment buttons
    $(".mark-received").on('click', mark_received)

    // key steps below

    $('#starRange').val(0)

    // save the information when switching
    $('#comment-leftbody').on('click', '.commentBody-li', function () {
        current = $(this).attr('id')
        $('#comment-right').children('form').children().attr('disabled', false)
        $(this).parent().parent().children().children().css('background-color','#7e4c4f')
        $(this).parent().parent().children().children().attr('disabled', false)
        $(this).css('background-color','#B59F85')
        $(this).attr('disabled', true)
        // preserve the comments and stars
        if(before != current){
            preserveCom(before)
        }
        // show the preserved comments and stars
        let currentPreCom = sessionStorage.getItem(current)
        $('#previousComment').text(currentPreCom)
        console.log('current ' + current)
        console.log()
        let currentPreStar = sessionStorage.getItem(current + '_star')
        // change starRange as default 0
        console.log('set: ' + currentPreStar)
        $('#starValue').text(currentPreStar)
        // $('#stars').html()
        // console.log(current+ 'star: ' + currentPreStar)
        before = current
    })

    // trigger of change the level of stars
    $('#starRange').on('change', function () {
        let value = $(this).val()
        console.log(value)
        $('#starValue').text(value)
        $('#stars').html('')
        for (let i = 0; i < parseInt(value); i ++){
            $('#stars').append('<img src=" static/bootstrap-icons/icons/star.svg ">')
        }

    })

    // save the information when modal is hidden
    // $("#cancel_comments").on('clik', function () {
    //     console.log('current: '+current)
    // })
    $(".close").on('click', function () {
        if(current == null){
            sessionStorage.setItem(first,  $('#commentArea').val())
            sessionStorage.setItem(first + '_star', $('#starValue').text())
        }else{
            if($("#previousComment").text() == ''){
                sessionStorage.setItem(current,  $('#commentArea').val())
            }
            // console.log('current: ' + current)
            // console.log('starvalue: ' +$('#starValue').text())
            let value = $('#starValue').text()
            sessionStorage.setItem(current + '_star', value)
            // console.log('save: ' + sessionStorage.getItem(current + '_star'))
        }
        // console.log('current: ' + current)
    })

    // trigger of send comments
    $('#confirm_comments').on('click', send_comment)
})

function send_comment(){
    // send details to the flask

    sessionStorage.setItem(current + '_star', $('#starValue').text())
    sessionStorage.setItem(current, $('#commentArea').val())
    passComment = true
    let dirSt = {}
    for(let i = 0; i < sessionStorage.length; i ++){
        let key = sessionStorage.key(i);
        let value = sessionStorage.getItem(key)
        let sp = key.split('_')
        if (/.*_star$/.test(key)){
            if ( value === ""){
                passComment = false
            }
        }
        dirSt[key] = value;
        console.log(i)
    }
    if(passComment){
        // add ajax submission
        $.post(
            '/api/make_comment',
            dirSt
        ).done(function (response) {
            let code = response['returnValue']
            console.log('success')
            // jump to order
            if (language === 'en'){
                toastAddSuccess('Thanks for your comment')
            }
            else{
                toastAddSuccess("谢谢您的评论");
            }
            // clear the session
            sessionStorage.clear()
        })
        $('#commentModal').removeClass('is-active')
        $('#commentModal').removeClass('is-animate')
    }else{
        if (language === 'en'){
            toastAddFail("Please give a star level to product(s)")
        }
        else{
            toastAddFail("请打分");
        }
    }

    console.log(dirSt)
}

function preserveCom(before){
    // preserve the comments and stars
    let area = $('#commentArea')
    let star = $('#starValue').text()
    let text = area.val()
    console.log(before + ' : ' +star)
    if(before == null){
        // for the first item (first item do not respond the click event)
        console.log('first: ' + first)
        sessionStorage.setItem(first, text)
        sessionStorage.setItem(first + '_star', star)
    }else{
        // for the other items
        if(text != ''){
            sessionStorage.setItem(before, text)
        }
        sessionStorage.setItem(before + '_star', star)
    }
    area.val('')
    $('#starRange').val(0)

}


function mark_received(){
    $('#stars').html('')
    let id = String($(this).parent().parent().children().children('.view-all').attr('id'))
    let button = $(this)
    console.log(button.text())
    let state = $(this).parent().parent().children('.order-state')
    console.log(button.text())
    if(String(button.text()).trim() == 'Mark as received' || String(button.text()).trim() == '确认收货'){
        $.post('/mark_received', {"orderID": id}).done(function (response){
            let code = response['success']
            console.log(code)
            if (code == 1){
                state.css('background-color', '#0be20c')
                if (language === 'en'){
                    state.text('finished')
                    button.text('Add a comment')
                    toastAddSuccess('Successfully marked as received')
                }
                else{
                    state.text('结束')
                    button.text('添加评论')
                    toastAddSuccess("打分成功");
                }

                button.addClass('comment')
            }
        })
    }else{
        let result;
        let html = '';
        $.post('/requestProductName',
            { orderID: id}
        ).done(function (response){
            result = response['result']
            // console.log(typeof result)
            let data = eval('(' + result + ')')
            // console.log(typeof data)
            let once = 0
            for (var key in data){
                if(once == 0){
                    first = key + '*' + id
                    html += '<li style="padding: 0.5em 0em"><button class="btn btn-primary commentBody-li" style="width: 100%; height: 100%; border-radius: 0.3em; background-color: #B59F85" disabled id="' + key + '*' + id +'">' + data[key] + '</button></li>'
                }else{
                    html += '<li style="padding: 0.5em 0em"><button class="btn btn-primary commentBody-li" style="width: 100%; height: 100%; border-radius: 0.3em; background-color: #7e4c4f" id="' + key +   '*' + id +'">' + data[key] + '</button></li>'
                }
                once ++;
            }

            // fill the content and show the comment if had added
            $('#comment-leftbody').children().html(html)
            $('#previousComment').text(sessionStorage.getItem(first))
            $('#starValue').text(sessionStorage.getItem(first + '_star'))
            $('#starRange').val(0)
            current = first
        })

        // show modal
        $('#commentModal').addClass('is-active')
        $('#commentModal').addClass('is-animate')
    }

}



function sendId(){
    let id = String($(this).attr('id'))
    $.post('writeID', {"orderID": id}).done(function (response){
        let code = response['success']
        if(code == 1){
            window.location.href = '/displayOrder'
        }
    })
}


function check_email_profile() {
    // validate the email
    let email = $("#changeEmail")
    window.alert(email.val())
    let regexp0 = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
    let address = String(email.val())
    let after = address.match(regexp0);
    // console.dir("after + " + after)
    if (after != null){
        email.removeClass("is-invalid")
        email.addClass("is-valid")
    }else{
        email.addClass("is-invalid")
        email.parent().children("div").text("Invalid email address")
        return false;
    }
}

function changeInformation2(){
    let state = $(":input[name='state']").val()
    let city = $(":input[name='city']").val()
    let address = $(":input[name='address']").val()
    let zip = $(":input[name='zip']").val()
    let phone = $(":input[name='phone']").val()
    $.ajax({
        type: "POST",
        dataType: "json",
        url: '/updateAddress',
        data: {
        'state':state,
        'city':city,
        'address':address,
        'zip':zip,
        'phone':phone,
        },
        traditional: true,
        error: function (XMLHttpRequest, textStatus, errorThrown) {window.alert("failed")},
        success: function (response){
            let code = response['returnValue'];
            if(code===1){
                window.alert("successfully");
                location.reload();
            }
            else{
                window.alert("fail in backend");
            }
        }
    });
}


function changePassword(){
    let oldPassword = $("#changeOldpassword").val()
    let newPassword = $("#changeNewpassword").val()
    $.ajax({
        type: "POST",
        dataType: "json",
        url: '/change_password',
        data: {
        'old':oldPassword,
        'new':newPassword,
        },
        traditional: true,
        error: function (XMLHttpRequest, textStatus, errorThrown) {window.alert("failed")},
        success: function (response){
            let code = response['returnValue'];
            if(code===1){
                window.alert("successfully");
                location.reload();
            }
            else if (code===0) {
                window.alert("wrong old password");
            }
            else{
                window.alert("fail in backend");
            }
        }
    });
}

function changeInformation3(){
    let cardname = $(":input[name='cardname']").val()
    let cardnumber = $(":input[name='cardnumber']").val()
    let expiredate = $(":input[name='expiredate']").val()
    let cvv = $(":input[name='cvv']").val()
    $.ajax({
        type: "POST",
        dataType: "json",
        url: '/updatePayment',
        data: {
        'cardname':cardname,
        'cardnumber':cardnumber,
        'expiredate':expiredate,
        'cvv':cvv,
        },
        traditional: true,
        error: function (XMLHttpRequest, textStatus, errorThrown) {window.alert("failed")},
        success: function (response){
            let code = response['returnValue'];
            if(code===1){
                window.alert("successfully");
                location.reload();
            }
            else{
                window.alert("fail in backend");
            }
        }
    });
}


function changeInformation() {
    updateProfilePhoto()
}



function updateProfilePhoto() {
    console.dir("update start")
    // choose anther new photo
    let con = $(".profile-upload__input").prop('files')[0];
    console.log(con)
    // create formData to hold data
    let formData = new window.FormData();
    formData.append("img", con)
    if(con!==null){
        console.dir("ajax start")
        $.ajax({
        type: 'post',
        url: '/get_photo',
        data: formData,
        processData: false,
        cache: false,
        contentType: false,
        enctype: 'enctype="multipart/form-data'
        }).done(function (response) {
        let server_code = response['returnValue']
        if(server_code === 0){
            console.dir("save success");
            let name = response['name'];
            let type = response['type'];
            console.dir(name);
            if(type === "user") {
                $(".profileImage").attr("src", "static/img/profile/" + name.toString() + "_profile.png");
            }else {
                // $(".img_photo").attr("src", "static/style/profile_photo/" + name.toString() + "_shopProfile.png");
            }
        }else {
            console.dir("save fail")
        }
    })
    }

}


$(function () {
    $("#changeVerification").click(function (event) {
        event.preventDefault();
        var lgajax = {
            'get':function(args) {
                args['method'] = 'get';
                this.ajax(args);
            },
            'post':function(args) {
                args['method'] = 'post';
                this.ajax(args);
            },
            'ajax':function(args) {
                // 设置csrftoken
                this._ajaxSetup();
                $.ajax(args);
            },
            '_ajaxSetup': function() {
                $.ajaxSetup({
                    'beforeSend':function(xhr,settings) {
                        if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type) && !this.crossDomain) {
                            var csrftoken = $('meta[name=csrf-token]').attr('content');
                            xhr.setRequestHeader("X-CSRFToken", csrftoken)
                        }
                    }
                });
            }
        };
        lgajax.get({                         // 这里ajax的方法是get方法
            'url': '/email_captcha_change/',         // 该url需要与视图函数中的路由相同
            'success': function (data) {
                if(data['code'] === 200){
                    window.alert('邮件发送成功！请注意查收！');
                }else{

                    window.alert("send fail");
                }
            },
            'fail': function (error) {
                abort(404);
            }
        });
    });
});



$(function () {
    $(":input[name='update1']").click(function (event) {
        event.preventDefault();
        check_email_profile();
        let emailE = $("#changeEmail");
        let captchaE = $("#changeCode");

        let email = emailE.val();
        let captcha = captchaE.val();
        if(email!==null){
            lgajax.post({
            'url': '/verify_code/',
            'data': {
                'email': email,
                'captcha': captcha
            },
            'success': function (data) {
                if(data['code'] === 200){
                    if(emailE.hasClass("is-valid")){

                        console.dir("check pass")
                        // sent the information to the backend

                        $.post(
                            '/change_email',
                            {
                                email: email
                            }
                        ).done(function (response) {
                            let server_code = response['returnValue'];
                            if (server_code === 1) {
                                window.alert('恭喜！修改成功！');
                                location.reload();
                            }else{
                                window.alert("line287")
                            }
                        }).fail(function () {
                            window.alert("Fail to connect the server")
                        })

                        return true;
                    }else {
                        // not sent the information
                        console.dir("the new email is not correct")
                        return false
                    }
                }else{
                    window.alert("the code is not correct");
                }
            },
            'fail': function (error) {
                abort(404);
            }
        });
        }
        else{
            window.alert("fill new email")
        }
    });
});

function toastAddSuccess(str){
    let tag = $(".toast-header").children("img");
    tag.attr("src", "/static/img/profile/success.png");
    $(".toast-body").text(str);
    $(".toast-body").addClass('')
    $("#liveToast").toast('show');
}

function toastAddFail(str){
    let tag = $(".toast-header").children("img");
    tag.attr("src", "/static/img/profile/fail.png");
    $(".toast-body").text(str);
    $("#liveToast").toast('show');
}