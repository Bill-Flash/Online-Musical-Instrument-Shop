$(document).ready(function () {
    // add event handler here
    $("#inputUsername").on("change", check_username)
    $("#inputEmail").on("change", check_email)
    $("#inputPassword").on("change", check_password)
    $("#inputConfirmation").on("change", check_confirmation)
    // $("#submitRegister").on("click", user_register)
    $("#submitLogin").on("click", user_login)
    $("#login-register").on("click", login_register)
    $(".dropdown-toggle").hover(function () {
        $(this).dropdown('toggle');
        $(this).dropdown('show');
    }, function () {
        // $(this).dropdown('hide');
    })

});


function login_register(){
    $(location).attr("href","/register");
}

function check_email() {
    // validate the email
    let email = $("#inputEmail")
    let regexp0 = /^\w+([\.\-\+]\w+)*@\w+([\.\-]\w+)*\.\w+$/;
    let address = String(email.val())
    let after = address.match(regexp0);
    // console.dir("after + " + after)
    if (after != null){
        email.removeClass("is-invalid")
        email.addClass("is-valid")
        check_email_in_db()
    }else{
        email.addClass("is-invalid")
            if (language === 'en'){
                email.parent().children("div").text("Invalid email address")
            }
            else{
                email.parent().children("div").text("无效的电子邮箱")
            }
        // email.parent().children("div").text("Invalid email address")
        return false;
    }
}

function check_password(){
    // validate the passwords
    let password = $("#inputPassword")
    let str = String(password.val());
    check_confirmation()
    if(str.length >= 8 && str.length <= 20 ){
        let regexp = /^[a-zA-Z\w]{7,19}$/;
        let after = str.match(regexp)
        // console.dir(after)
        if(after != null){
            password.removeClass("is-invalid")
            password.addClass("is-valid")
            return true
        }else{
            password.addClass("is-invalid")
            if (language === 'en'){
                password.parent().children("div").text("Invalid password")
            }
            else{
                password.parent().children("div").text("无效的密码")
            }
            // password.parent().children("div").text("Invalid password")
            return false;
        }
    }else{
        password.addClass("is-invalid")
        if (language === 'en'){
            password.parent().children("div").text("Incorrect length of password")
            }
            else{
            password.parent().children("div").text("密码长度错误")
            }
            password.parent().children("div").text("Incorrect length of password")
        return false;
    }
}

function check_confirmation(){
    // validate the confirmation
    console.dir("confirm change")
    let password = $("#inputPassword")
    let confirm = $("#inputConfirmation")
    let str = String(password.val());
    let confirmation = String(confirm.val());
    if(confirmation == str){
        console.dir("confirmation true")
        confirm.removeClass("is-invalid")
        confirm.addClass("is-valid")
        return true;
    }else {
        confirm.addClass("is-invalid")
        if (language === 'en'){
        confirm.parent().children("div").text("Inconsistent with password")
            }
            else{
        confirm.parent().children("div").text("与密码不一致")
            }
        confirm.parent().children("div").text("Inconsistent with password")
        return false;
    }
}


function check_username() {
    // validate the username
    console.dir("user change")
    let username = $("#inputUsername");
    let str = String(username.val())
    if(str.length >= 6 && str.length <= 30){
        let regexp = /^[a-zA-Z\w][a-zA-Z0-9_]{5,28}$/;
        let after = str.match(regexp)
        // console.dir(after)
        if(after != null){
            username.removeClass("is-invalid")
            username.addClass("is-valid")
            check_username_in_db()
        }else{
            username.addClass("is-invalid")
            if (language === 'en'){
                username.parent().children("div").text("Invalid username")
            }
            else{
                username.parent().children("div").text("无效的用户名")
            }
                // username.parent().children("div").text("Invalid username")
            return false;
        }
    }else{
        username.addClass("is-invalid")
        if (language === 'en'){
        username.parent().children("div").text("Incorrect length of username")
            }
            else{
        username.parent().children("div").text("无效的用户名长度")
            }
        // username.parent().children("div").text("Incorrect length of username")
        return false;
    }
}

function check_email_in_db(){
    //check the availability of the email
    let email = $("#inputEmail")
    $.post(
        '/checkEmail',
        {email: email.val()}
    ).done(function (response) {
        let server_code = response['returnValue'];
        if (server_code == 0) {
            console.dir("email pass")
            email.removeClass("is-invalid")
            email.addClass("is-valid")
            return true
        } else {
            console.dir("email not pass")
            email.addClass("is-invalid")
            if (language === 'en'){
                email.parent().children("div").text("Invalid email address")
            }
            else{
                email.parent().children("div").text("无效的电子邮箱")
            }
            email.parent().children("div").text("This email has been registered")
            return false
        }
    }).fail(function () {
        if (language === 'en'){
                email.parent().children("div").text("Invalid email address")
            }
            else{
                email.parent().children("div").text("无效的电子邮箱")
            }
        email.parent().children("div").text("Fail to connect the server")
        return false
    })
}

function check_username_in_db(){
    //check the availability of the username
    let username = $("#inputUsername");
    $.post(
        '/checkUsername',
        {username: username.val()}
    ).done(function (response) {
        let server_code = response['returnValue'];
        if (server_code == 0) {
            console.dir("username pass")
            username.removeClass("is-invalid")
            username.addClass("is-valid")
            return true
        } else {
            console.dir("username not pass")
            username.addClass("is-invalid")
            if (language === 'en'){
                email.parent().children("div").text("Invalid email address")
            }
            else{
                email.parent().children("div").text("无效的电子邮箱")
            }
            username.parent().children("div").text("This username has been registered")
            return false
        }
    }).fail(function () {
        if (language === 'en'){
                email.parent().children("div").text("Invalid email address")
            }
            else{
                email.parent().children("div").text("无效的电子邮箱")
            }
        username.parent().children("div").text("Fail to connect the server")
        return false
    })
}


// function user_register() {
//     // register an account
//     let checkBox = $("#customCheck");
//     let email = $("#inputEmail");
//     let username = $("#inputUsername");
//     let password = $("#inputPassword");
//     let confirmation = $("#inputConfirmation");
//     let address = $("#inputAddress")
//     let city = $("#inputCity")
//     let state = $("#inputState")
//     let zip = $("#inputZip")
//     if(email.hasClass("is-valid") &&
//         username.hasClass("is-valid") &&
//         password.hasClass("is-valid") &&
//         confirmation.hasClass("is-valid") &&
//         checkBox.prop("checked")){
//
//         console.dir("check pass")
//         // sent the information to the backend
//
//         $.post(
//             '/register',
//             {
//                 username: username.val(),
//                 email: email.val(),
//                 password: password.val(),
//                 address: address.val(),
//                 city: city.val(),
//                 state: state.val(),
//                 zip: zip.val()
//             }
//         ).done(function (response) {
//             let server_code = response['returnValue'];
//             if (server_code == 0) {
//                 console.dir("send success")
//                 window.location.href = "http://127.0.0.1:5000/index"
//             }else{
//                 console.dir("send fail")
//             }
//         }).fail(function () {
//             console.dir("Fail to connect the server")
//         })
//
//         return true;
//     }else {
//         // not sent the information
//         console.dir("check not pass")
//         return false
//     }
//
// }

function user_login(){
    let user = $("#loginUsername");
    let password = $("#loginPassword");
    let type = 0;
    if(user != null && password != null){
        let str = String(user.val());
        let regexp0 = /^\w+([\.\-\+]\w+)*@\w+([\.\-]\w+)*\.\w+$/;
        let after = str.match(regexp0);
        if(after == null){
            // login by username
            type = 0;
        }else{
            // login by email
            type = 1;
        }
        console.log(type)
        $.post(
            '/login',
            {
                name: user.val(),
            password: password.val(),
                type: type
            }
        ).done(function (response) {
            let server_code = response['returnValue'];
            user.removeClass("is-invalid")
            password.removeClass("is-invalid")
            if (server_code === 0) {
               // window.alert("login success")
                user.removeClass("is-invalid")
                password.removeClass("is-invalid")
                $.ajax(
                {
                    type:'POST',
                    async:false,
                    url:'/api/get_user',
                    success: function(data) {
                    if (data['type'] === 'user')
                        $(location).attr("href","/")
                    else
                        $(location).attr("href","/staff")
                    }
                }
            );
            } else if(server_code === 1) {
                //window.alert("no such user")
                console.dir("No such user")
                user.addClass("is-invalid")
                if (language === 'en'){
                    user.parent().children("div").text("No such user")
                }
                else{
                    user.parent().children("div").text("没有这个用户")
                }
                // user.parent().children("div").text("No such user")
            } else if(server_code === 2){
                //window.alert("incorrect password ")
                password.addClass("is-invalid")
                if (language === 'en'){
                    password.parent().children("div").text("Incorrect password")
                }
                else{
                    password.parent().children("div").text("密码错误")
                }
                // password.parent().children("div").text("Incorrect password")
            }
        }).fail(function () {
            if (language === 'en'){
                window.alert("login fail")
            }
            else{
                window.alert("登录失败")
            }
            // window.alert("login fail")
        })
    }else{

    }

}
