let userdetype
let userdename
let language = "en"
$(document).ready(function () {
    $.ajax(
        {
            type:'POST',
            async:false,
            dataType:"JSON",
            url:'/api/get_user',
            success: function(data) {
            userdename = data['name'];
            userdetype = data['type'];
            }
        }
    );
    $.ajax(
        {
            type:'POST',
            async:false,
            dataType:"JSON",
            url:'/api/get_language',
            success: function(data) {
            language = data['lan'];
            }
        }
    );
    // add event handler here
    const observer = new IntersectionObserver(changes => {
        for (const change of changes){
            // add / remove the class in the classList
            let isIntersect = change.intersectionRatio
            let conclude = document.querySelector('#conclude')
            if(isIntersect !== 0){
                console.log("in")
                conclude.classList.remove('fixed-bottom')
            }else{
                console.log("out")
                conclude.classList.add('fixed-bottom')
            }
        }
    })
    if(document.documentURI.match(/shopping_cart/)){
        observer.observe(document.querySelector('.cart-shiping-update-wrapper'))
    }
    $(".addtocart-btn").on("click", addToCart_list);
    $(".hoverAdd").on("click", addToCart_hover);
    $(".quickView-add").on("click", addToCart_quick);
    console.log('do this step')
    $("#addToCart_detail").on("click", addToCart_inDetail);
    $("input[name='qtybutton']").attr('disabled', true);
    $(".product-remove").children().on("click", delete_shopping)
    $("#cart_clear").on('click', clear_shopping)
    $("#delete-select").on('click',clear_shopping)
    $(".minus-num").on('click', validate_minus)
    $(".plus-num").on('click', validate_plus)
    $("#select-all").on('click', select_all )
    $(".checkbox-cart").on('change', select)
    $(".Removed").each(function (){
        $(this).children().attr('disabled', true)
        let text = $(this).parent().children('.product-name').children().text()
        $(this).parent().children('.product-name').children().text(text + '(removed)')
        $(this).parent().children('.product-name').children().css('color', 'red')
    })
    // for entering to the next order page
    $("#order-select").on('click', pass_data)


    // prevent the inverse order by users
    $( "#amount" ).on('input', function (){
        value = $(this).val();
        matches = value.match(/^\$\d+ - \$\d+$/) || [];
        if (!matches.length){
            if (language === 'en') {
                toastAddFail(value+" is in a wrong format");
            }
            else{
                toastAddFail(value+"是错误格式");
            }
             $(this).val("$" + $( "#slider-range" ).slider( "values", 0 ) +
                 " - $" + $( "#slider-range" ).slider( "values", 1 ))
        }
    })

});

function pass_data(){
    // product tr tags that have be selected
    let dic = {}
    let isAdd = false;
    $('.selected-product').each(function () {
        isAdd = true
        let id = String($(this).attr('name'))
        let num = String($(this).children('.product-quantity').children('.cart-plus-minus').children().attr('value'));
        console.log(id)
        console.log(num)
        dic[id] = num
    })
    dic['total'] = $('#total-cost').text()

    if(isAdd){
        $.post(
            '/writeDetails',
            dic
        ).done(function (response) {
            let code = response['success']
            console.log('success')
            // jump to order
            window.location.href = '/order'
        })

    }else{

    }

}

function make_order(){
    let selected_item = $("input.checkbox-cart:checked");
    if(selected_item.length===0){
        modalConfirmation("You have not select item.");
    }
    else{
        let myarray = [];
        selected_item.each(function (){
            myarray.push($(this).parent().parent().attr('name'));
            myarray.push($(this).parent().parent().find($(".cart-plus-minus-box")).val());
        });
        let farray = JSON.stringify(myarray)
        $.ajax({
                type: "POST",
                dataType: "json",
                url: '/api/buy_good',
                async:false,
                data: {
                'map':farray,
                'cost':$("#total-cost").text()
                },
                traditional: true,
                error: function (XMLHttpRequest, textStatus, errorThrown) {window.alert("server failed")},
                success: function (response){
                    let code = response['returnValue'];
                    if (language === 'en'){
                        if(code===0){
                            modalConfirmation("purchase successfully");
                        }
                        else if (code===1){
                            modalConfirmation("something you buy are now closed for buying");
                        }
                        else if (code===2){
                            modalConfirmation("something you buy is out of inventory");
                        }
                    }else{
                        if(code===0){
                            modalConfirmation("购买成功");
                        }
                        else if (code===1){
                            modalConfirmation("商品已经下架");
                        }
                        else if (code===2){
                            modalConfirmation("商品已经售罄");
                        }
                    }
                    // if(code===0){
                    //     modalConfirmation("purchase successfully");
                    // }
                    // else if (code===1){
                    //     modalConfirmation("something you buy are now closed for buying");
                    // }
                    // else if (code===2){
                    //     modalConfirmation("something you buy is out of inventory");
                    // }
                }
            });
    }


}

function clear_shopping(){
    let id = $(this).attr('id');
    let ar = [];
    if(id === 'delete-select'){
        let all = $('.selected-product');
        all.each(function () {
            ar.push(String($(this).attr('name')))
            $(this).removeClass('selected-product')
        })
        if (ar.length !== 0){
            $.ajax({
            url: '/deleteShopping',
            data: {productID : ar, type : 'select'},
            traditional: true,
            type: 'post',
            async:false,
            dataType: 'json'
        }).done(function (response){
                let server_code = response['returnValue'];
                if (server_code === 0){
                    all.remove()
                    if (language === 'en'){
                        toastAddSuccess("Successfully remove it from your cart");
                    }
                    else{
                        toastAddSuccess("成功移除");
                    }
                }else{
                    if (language === 'en'){
                        toastAddFail("Unknown error");
                    }
                    else{
                        toastAddFail("出现错误");
                    }
                }
        }).fail({

        })
        }
        else{
           if (language === 'en'){
                toastAddFail("You select nothing");
            }
            else{
                toastAddFail("没有选择的商品");
            }
        }
    }else{
        console.log('clear all')
    }
    calculate_cost()
}

function calculate_cost(){
    // let lst = $(".selected-product").children(".product-subtotal")
    let cost = 0
    $(".selected-product").each(function (){
        let num = String($(this).children(".product-subtotal").text()).substring(1)
        cost = cost + parseInt(num)
    })
    $("#total-cost").text('$' + cost)
}

function select(){
    if($(this).prop('checked') == true){
        $(this).parent().parent().addClass('selected-product')
    }else{
        $(this).parent().parent().removeClass('selected-product')
    }
    calculate_cost()
}

function select_all(){
    let all = $(".checkbox-cart")
    if($(this).prop('checked') == true){
        all.prop('checked', true)
        all.parent().parent().addClass('selected-product')
    }else{
        all.prop('checked', false)
        all.parent().parent().removeClass('selected-product')
    }
    calculate_cost()
}

function delete_shopping(){
    let row = $(this).parent().parent()
    let id = String($(this).parent().parent().children('.product-name').children().prop('href'))
    let id_re = id.match(/20\d.*/)[0]
    let ar = [id_re]
    $.ajax({
        url: '/deleteShopping',
        data: {productID : ar, type:'single'},
        traditional: true,
        type: 'post',
        async:false,
        dataType: 'json'
    }).done(function (response){
            let server_code = response['returnValue'];
            if (server_code === 0){
                row.removeClass('selected-product')
                row.remove()
                if (language === 'en'){
                    toastAddSuccess("Successfully remove it from your cart");
                }
                else{
                    toastAddSuccess("成功移除出购物车");
                }
            }else{
                if (language === 'en'){
                    toastAddFail("Unknown error");
                }
                else{
                    toastAddFail("未知错误");
                }
            }
    }).fail({

    })
    calculate_cost()
}

function validate_plus(){
    let quantity = $(this).parent().children('div').children()
    let total = $(this).parent().parent().children('.product-subtotal')
    let id = String($(this).parent().parent().children('.product-name').children().prop('href'))
    let num = parseInt(quantity.attr('value'))
    console.log('num: '+ quantity.prop('value'))
    if (num < 9999){
        quantity.attr('value', String(num + 1))

        let id_re = id.match(/20\d.*/)[0]
        $.post(
            '/changeNumberInCart',
            {
                num: num + 1,
                productID: id_re,
            }
        ).done(function (response) {
            let server_code = response['returnValue'];
            if (server_code == 0) {
                let number = response['num']
                let price = response['price']
                console.log('number: ' + number)
                total.text('$' + parseFloat(price) * parseFloat(number))
                if (language === 'en'){
                    toastAddSuccess("Successfully change the number");
                }
                else{
                    toastAddSuccess("修改数量成功");
                }
                calculate_cost()
            } else {
                console.log("fail");
                if (language === 'en'){
                    toastAddFail("Unknown error");
                }
                else{
                    toastAddFail("未知错误");
                }
            }
        }).fail(function () {
            return false;
        })
    }else if (num = 9999){

    }else{
        if (language === 'en'){
            toastAddFail("Already up to upper bound")
        }
        else{
            toastAddFail("以达数量上限");
        }
    }
}

function validate_minus(){
    let quantity = $(this).parent().children('div').children()
    let total = $(this).parent().parent().children('.product-subtotal')
    let id = String($(this).parent().parent().children('.product-name').children().prop('href'))
    let num = parseInt(quantity.attr('value'))
    console.log(num)
    if (num > 1){
        quantity.attr('value', String(num - 1))
        let id_re = id.match(/20\d.*/)[0]
        $.post(
            '/changeNumberInCart',
            {
                num: num - 1,
                productID: id_re,
            }
        ).done(function (response) {
            let server_code = response['returnValue'];
            if (server_code == 0) {
                let number = response['num']
                let price = response['price']
                total.text('$' + parseFloat(price) * parseFloat(number))
                if (language === 'en'){
                    toastAddSuccess("Successfully change the number");
                }
                else{
                    toastAddSuccess("修改数量成功");
                }
                calculate_cost()
            } else {
                console.log("fail");
                if (language === 'en'){
                    toastAddFail("Unknown error");
                }
                else{
                    toastAddFail("未知错误");
                }
            }
        }).fail(function () {
            return false;
        })
    }else{
        if (language === 'en'){
            toastAddFail("Already down to lower bound")
        }
        else{
            toastAddFail("以达数量下限");
        }
    }
}

function validation(){
    let value = String($(this).val());
    let regex = /^[1-9]\d{0,4}$/;
    let result = value.match(regex);
    console.log(result)
    if(result == null){
        $(this).prop('value', '1')
        if (language === 'en'){
            toastAddFail("Invalid quantity")
        }
        else{
            toastAddFail("无效数量");
        }
    }else{
        if($(this).parent().parent().attr('class') == 'product-quantity'){
            $(this).attr('disabled', true)
            // let id = String($(this).parent().parent().parent().children('.product-name').children().prop('href'))
            // let total = $(this).parent().parent().parent().children('.product-subtotal')
            // let id_re = id.match(/20\d.*/)[0]
            // console.log("in shopping cart")
            // console.log(value)
            // $.post(
            //     '/changeNumberInCart',
            //     {
            //         num: value,
            //         productID: id_re,
            //     }
            // ).done(function (response) {
            //     let server_code = response['returnValue'];
            //     if (server_code == 0) {
            //         let num = response['num']
            //         let price = response['price']
            //         total.text('$' + parseFloat(price) * parseFloat(num))
            //         toastAddSuccess("Successfully change the number");
            //     } else {
            //         console.log("fail");
            //         toastAddFail("Unknown error");
            //     }
            // }).fail(function () {
            //     return false;
            // })
        }
    }
}

function addToCart_list(){
    let id = $(this).attr("id")
    let number = 1
    let userdetype
    let userdename
    $.ajax(
        {
            type:'POST',
            async:false,
            url:'/api/get_user',
            success: function(data) {
            userdename = data['name'];
            userdetype = data['type'];
            }
        }
    );
    if(userdetype === "user"){
    // sent the details to the server side
        $.post(
            '/addToCart',
            {
                num: number,
                productID: id,
                username: userdename
            }
        ).done(function (response) {

            let server_code = response['returnValue'];
            if (server_code === 0) {
                console.log("success");
                // should hide the modal
                if (language === 'en'){
                    toastAddSuccess("Successfully add to your cart");
                }
                else{
                    toastAddSuccess("成功添加购物车");
                }
            } else if(server_code === 1) {

                // should hide the modal
                if (language === 'en'){
                    toastAddFail("You have already added it to your cart");
                }
                else{
                    toastAddFail("您已添加过购物车");
                }
            }
        }).fail(function () {

            return false;
        })
    }else{
        if (language === 'en'){
            toastAddFail("You are not a customer")
        }
        else{
            toastAddFail("您不是顾客");
        }
    }
}

function addToCart_inDetail(){
    let userdetype
    let userdename
    $.ajax(
        {
            type:'POST',
            async:false,
            dataType:"JSON",
            url:'/api/get_user',
            success: function(data) {
            userdename = data['name'];
            userdetype = data['type'];
            }
        }
    );
    let title = window.location.pathname;
    let id = '#' + title.match(/20\d*/)[0];
    console.log(id)
    let number = $("input[name='qtybutton']");
    // window.alert(userdetype)
    console.log(number.val())
    console.log(id)
    if(userdetype === "user"){

        // sent the details to the server side
        $.post(
            '/addToCart',
            {
                num: number.val(),
                productID: id,
                username: userdename
            }
        ).done(function (response) {
            let server_code = response['returnValue'];
            console.log(server_code)
            if (server_code == 0) {
                console.log("success");
                if (language === 'en'){
                    toastAddSuccess("Successfully add to your cart");
                }
                else{
                    toastAddSuccess("成功添加购物车");
                }
            } else if(server_code == 1) {
                console.log("fail");
                if (language === 'en'){
                    toastAddFail("You have already added it to your cart");
                }
                else{
                    toastAddFail("您已添加过购物车");
                }
            }
        }).fail(function () {
            return false;
        })
    }else{
        if (language === 'en'){
            toastAddFail("You are not a customer")
        }
        else{
            toastAddFail("您还不是顾客");
        }
    }
}


function addToCart_quick(){
    let modal = $(this).parent().parent().parent().parent().parent().parent().parent().parent();
    let id = modal.attr("id").substring(5);
    let number = $(this).parent().parent().children(".cart-plus-minus").children();
    console.log(modal);
    let userdetype
    let userdename
    $.ajax(
        {
            type:'POST',
            async:false,
            url:'/api/get_user',
            success: function(data) {
            userdename = data['name'];
            userdetype = data['type'];
            }
        }
    );
    if(userdetype === "user"){
    // sent the details to the server side
        $.post(
            '/addToCart',
            {
                num: number.val(),
                productID: id,
                username: userdename
            }
        ).done(function (response) {

            let server_code = response['returnValue'];
            if (server_code === 0) {
                console.log("success");
                // should hide the modal
                console.log(modal.modal('hide'));
                if (language === 'en'){
                    toastAddSuccess_modal("Successfully add to your cart");
                }
                else{
                    toastAddSuccess_modal("成功添加购物车");
                }
            } else if(server_code === 1) {
                console.log("fail");
                // should hide the modal
                console.log(modal.modal('hide'));
                if (language === 'en'){
                    toastAddFail_modal("You have already added it to your cart");
                }
                else{
                    toastAddFail_modal("您已添加过购物车");
                }
            }
        }).fail(function () {

            return false;
        })
    }else{
        if (language === 'en'){
            toastAddFail_modal("You are not a customer")
        }
        else{
            toastAddFail_modal("您不是顾客");
        }
    }
}


function addToCart_hover(){
    let id = "#" + String($(this).parent().parent().children("a").attr('href')).match(/20\d.*/);
    let username = String($("#usernameNav").text()).trim();
    // console.log(id)
    if(userdetype !== "Tourist"){
        // sent the details to the server side
        $.post(
            '/addToCart',
            {
                num: 1,
                productID: id,
                username: username
            }
        ).done(function (response) {
            let server_code = response['returnValue'];
            if (server_code == 0) {
                console.log("success")
                if (language === 'en'){
                    toastAddSuccess("Successfully add to your cart")
                }
                else{
                    toastAddSuccess("成功添加购物车");
                }
            } else if(server_code == 1) {
                if (language === 'en'){
                    toastAddFail("You have already added it to your cart")
                }
                else{
                    toastAddFail("您已添加过购物车");
                }
            }
        }).fail(function () {
            return false
        })

    }else{
            if (language === 'en'){
                toastAddFail("You are still tourist, please login to add it into your cart")
            }
            else{
                toastAddFail("您还是游客，请登录以添加购物车");
            }
    }
}


function toastAddSuccess(str){
    let tag = $(".toast-header").children("img");
    tag.attr("src", "/static/img/profile/success.png");
    $(".toast-body").text(str);
    $("#liveToast").toast('show');
}

function toastAddSuccess_modal(str){
    let tag = $(".toast-header").children("img");
    tag.attr("src", "/static/img/profile/success.png");
    $(".toast-body").text(str);
    $(".special").toast('show');
}

function toastAddFail(str){
    let tag = $(".toast-header").children("img");
    tag.attr("src", "/static/img/profile/fail.png");
    $(".toast-body").text(str);
    $("#liveToast").toast('show');
}

function toastAddFail_modal(str){
    let tag = $(".toast-header").children("img");
    tag.attr("src", "/static/img/profile/fail.png");
    $(".toast-body").text(str);
    $(".special").toast('show');
}


function modalConfirmation (str){
    $("#confirmation-body").text(str)
    $("#exampleModal").modal({show:true})
}
